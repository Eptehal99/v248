#!/usr/bin/env python
# coding: utf-8

# # Overview
# The purpose of this notebook is to visually & numerically compare the implied prior generate by the NSB approach versus our hierarchical approach, and see how they differ

# In[1]:


import math

import arviz as az
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import pymc as pm
from pytensor.tensor import TensorVariable
import pytensor.tensor as pt
from scipy import stats
import torch
from torch import distributions, optim, nn


# ## NSB Estimator

# In[2]:


def nsb_logp(value: TensorVariable, K) -> TensorVariable:
    val1 = K * pt.math.tri_gamma((K * value) + 1)
    val2 = pt.math.tri_gamma(value + 1)
    val = val1 - val2

    return pt.switch(
        value <= 0.,
        -np.inf,
        pt.log(val)
    )


# In[3]:


def nsb_prior(K: int, draws: int = 30000, tune: int = 10000):
    with pm.Model() as nsb:
        a = pm.CustomDist('a', K, logp=nsb_logp)

        idata = pm.sample(draws=draws, tune=tune, random_seed=17, initvals={'a': 0.01}, step=pm.Metropolis())

    return idata


# In[4]:


idata3 = nsb_prior(K=6)


# In[5]:


idata4 = nsb_prior(K=24)


# In[6]:


idata5 = nsb_prior(K=120)


# In[7]:


idata6 = nsb_prior(K=720, draws=40000)


# In[8]:


def gen_permen_samples(idata, k: int, rng: np.random.Generator, samples: int = 4000) -> np.ndarray:
    a = az.extract(idata, var_names='a', num_samples=samples, rng=rng)
    A = np.tile(a, (k, 1)).T
    d = pm.Dirichlet.dist(A)

    H = stats.entropy(pm.draw(d, random_seed=rng), axis=-1)
    H /= math.log(k)
    return H


# In[9]:


def compute_objective(
    idata,
    k: int,
    mu: np.ndarray,
    rng: np.random.Generator,
    samples: int = 4000
) -> float:

    H = gen_permen_samples(idata, k, rng=rng, samples=samples)
    return stats.wasserstein_distance(H, mu)


# In[10]:


def get_obj_performance(
    idata,
    k: int,
    mu: np.ndarray,
    rng: np.random.Generator,
    samples: int = 4000,
    num_reps: int = 25,
) -> pd.Series:

    out = pd.Series(index=np.arange(num_reps), dtype=float)
    for i in range(num_reps):
        out.loc[i] = compute_objective(idata, k, mu=mu, rng=rng, samples=samples)

    return out


# In[11]:


rng = np.random.default_rng(17)


# In[12]:


mu = rng.beta(1, 1, size=10000)


# In[13]:


obj3 = get_obj_performance(idata3, k=6, mu=mu, rng=rng, num_reps=25)


# In[14]:


obj4 = get_obj_performance(idata4, k=24, mu=mu, rng=rng)


# In[15]:


obj5 = get_obj_performance(idata5, k=120, mu=mu, rng=rng)


# In[16]:


obj6 = get_obj_performance(idata6, k=720, mu=mu, rng=rng)


# In[17]:


print(obj3.mean())
print(obj3.std())


# In[18]:


print(obj4.mean())
print(obj4.std())


# In[19]:


print(obj5.mean())
print(obj5.std())


# In[20]:


print(obj6.mean())
print(obj6.std())


# ## Our Approach

# In[21]:


def wasserstein_distance(u: torch.Tensor, v: torch.Tensor):
    u_sorter = torch.argsort(u)
    v_sorter = torch.argsort(v)

    all_values = torch.concatenate((u, v))
    all_values = all_values.sort().values

    # Compute the differences between pairs of successive values of u and v.
    deltas = torch.diff(all_values)

    # Get the respective positions of the values of u and v among the values of
    # both distributions.
    u_cdf_indices = torch.searchsorted(u[u_sorter], all_values[:-1], side="right")
    v_cdf_indices = torch.searchsorted(v[v_sorter], all_values[:-1], side="right")

    u_cdf = u_cdf_indices / u.shape[0]
    v_cdf = v_cdf_indices / v.shape[0]

    return torch.sum(torch.multiply(torch.abs(u_cdf - v_cdf), deltas))


def get_torch_entropy_samples(
    a: torch.Tensor,
    b: torch.Tensor,
    k: int,
    num_samples: int = 10000,
) -> torch.Tensor:

    alpha = distributions.Gamma(a, b).rsample(sample_shape=(num_samples,))
    ptilde = distributions.Normal(0, alpha).rsample(sample_shape=(k,)).T
    
    H = distributions.Categorical(logits=ptilde).entropy() / torch.log(
        torch.tensor(k).float()
    )

    return H
    

def optimize_hyperprior(
    mu: torch.Tensor, 
    m: int,
    a_start: float,
    b_start: float,
    num_samples=10000,
    lr=0.01,
    num_epochs=1000
):
    a = nn.Parameter(torch.tensor(a_start))
    b = nn.Parameter(torch.tensor(b_start))
    optimizer = optim.Adam([a, b], lr=lr)

    a_star, b_star = a.item(), b.item()
    v_star = float("inf")
    k = math.factorial(m)

    for epoch in range(num_epochs):
        optimizer.zero_grad()
        H = get_torch_entropy_samples(a, b, k, num_samples=num_samples)
        
        loss = wasserstein_distance(H, mu)
        loss.backward()
        optimizer.step()

        if loss.item() < v_star:
            a_star, b_star = a.item(), b.item()
            v_star = loss.item()

        if epoch % 100 == 0:
            print(
                f"Epoch {epoch}, W1 Loss: {loss.item()}, a: {a.item()}, b: {b.item()}"
            )

    return v_star


# In[22]:


def get_torch_obj_performance(
    mu: torch.Tensor, 
    m: int,
    a_start: float,
    b_start: float,
    num_epochs: int = 1000,
    num_samples: int = 10000,
    num_reps: int = 25,
):
    
    torch.manual_seed(17)
    out = pd.Series(index=np.arange(num_reps))

    for i in range(num_reps):
        out.loc[i] = optimize_hyperprior(mu, m, a_start, b_start, num_samples, num_epochs=num_epochs)

    return out


# In[23]:


torch_obj3 = get_torch_obj_performance(torch.Tensor(mu), m=3, a_start=2., b_start=1.)


# In[24]:


print(torch_obj3.mean())
print(torch_obj3.std())


# In[25]:


torch_obj4 = get_torch_obj_performance(torch.Tensor(mu), m=4, a_start=2., b_start=1.)


# In[26]:


torch_obj5 = get_torch_obj_performance(torch.Tensor(mu), m=5, a_start=2.093355655670166, b_start=0.6178128719329834)


# In[27]:


print(torch_obj4.mean())
print(torch_obj4.std())


# In[28]:


print(torch_obj5.mean())
print(torch_obj5.std())


# In[29]:


torch_obj6 = get_torch_obj_performance(torch.Tensor(mu), m=6, a_start=2.3356635570526123, b_start=0.6543197631835938, num_epochs=300)


# In[30]:


print(torch_obj6.mean())
print(torch_obj6.std())


# In[31]:


stats.ttest_ind(torch_obj3.values, obj3.values, equal_var=False, alternative='less')


# In[32]:


stats.ttest_ind(torch_obj4.values, obj4.values, equal_var=False, alternative='less')


# In[33]:


stats.ttest_ind(torch_obj5.values, obj5.values, equal_var=False, alternative='less')


# In[34]:


stats.ttest_ind(torch_obj6.values, obj6.values, equal_var=False, alternative='less')