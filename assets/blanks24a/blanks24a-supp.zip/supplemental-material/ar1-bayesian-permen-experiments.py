#!/usr/bin/env python
# coding: utf-8

# # Overview
# The purpose of this notebook is to evaluate our proposed Bayesian PermEn estimator for the synthetic AR(1) signals. We will evaluate the performance of the NSB estimator and a Bayesian estimator with the "Perk's Prior": ($\alpha = \frac{1}{m!}$), and consider how the performance of the estimators is affected by the embedding dimension and signal length.

# In[1]:


from collections import Counter
from itertools import permutations
import math

import antropy as ant
import arviz as az
import ndd
import numpy as np
import pandas as pd
import pymc as pm
import pytensor
import pytensor.tensor as pt
from tqdm import tqdm
from scipy import stats
from statsmodels.tsa.arima_process import arma_generate_sample


# Using the PyTorch framework, we got the optimal $(\alpha, \beta)$ parameter values for the Gamma hyperprior given the embedding dimension size and the desired PermEn reference prior.

# In[2]:


GAMMA_HYPERPRIOR = {
    5: {
        (1, 1): (2.093355655670166, 0.6178128719329834),
        (10, 2): (8.217537879943848, 6.420329570770264),
    },
    6: {
        (1, 1): (2.3356635570526123, 0.6543197631835938),
        (10, 2): (8.134527206420898, 5.572224140167236),
    }
}


# In[3]:


class BayesianPermEn:
    def __init__(
        self, 
        X: np.ndarray,
        m: int,
        alpha: float = None,
        beta: float = None,
        random_seed: int = None,
        draws: int = 1000,
        return_std: bool = False
    ):
        self.X = X
        self.m = m
        self.alpha = alpha
        self.beta = beta
        self.random_seed = random_seed
        self.draws = draws
        self.return_std = return_std
        
        self.idata_ = None

    def _embed(self, x: np.ndarray) -> np.ndarray:
        shape = (x.size - self.m + 1, self.m)
        strides = (x.strides[0], x.strides[0])
        X = np.lib.stride_tricks.as_strided(x, shape=shape, strides=strides)
        return np.argsort(X, axis=1)

    def _count_permutations(self, X: np.ndarray) -> None:
        c = Counter({perm: 0. for perm in permutations(range(self.m))})
        for row in X:
            c[tuple(row)] += 1

        c = np.array(list(c.values()))
        return c

    def _get_all_counts(self) -> np.ndarray:
        n = self.X.shape[0]
        k = math.factorial(self.m)
        C = np.zeros((n, k))

        for i in range(n):
            Xtmp = self._embed(self.X[i, :])
            C[i, :] = self._count_permutations(Xtmp)

        return C

    def permen(self):
        C = self._get_all_counts()
        
        n = self.X.shape[0]
        N = self.X.shape[1] - self.m + 1
        k = math.factorial(self.m)
        coords = {'support': np.arange(k), 'signal': np.arange(n)}

        with pm.Model(coords=coords) as model:
            a = pm.Gamma('a', self.alpha, self.beta, shape=(n, 1), dims='signal')
            theta = pm.Normal('theta', 0, 1, dims=('signal', 'support'))
            logit_pi = pm.Deterministic('logit_pi', a * theta, dims=('signal', 'support'))
            pi = pm.Deterministic('pi', pt.special.softmax(logit_pi, axis=-1), dims=('signal', 'support'))
            c = pm.Multinomial('c', n=N, p=pi, observed=C)
                
            self.idata_ = pm.sample(draws=self.draws, random_seed=self.random_seed, nuts={'target_accept':0.9})
                
        # Compute the posterior PermEn distribution
        h = stats.entropy(self.idata_.posterior['pi'].values, axis=-1) / math.log(k)
        self.idata_.posterior['permen'] = (['chain', 'draw', 'signal'], h)

        mu = self.idata_.posterior['permen'].mean(dim=['chain', 'draw']).data

        if self.return_std:
            sigma = self.idata_.posterior['permen'].std(dim=['chain', 'draw']).data
            return mu, sigma
        else:
            return mu


# ## Embedding Dimension Size: $m = 5$

# In[4]:


rng = np.random.default_rng(2017)


# In[5]:


start_idx = rng.integers(low=0, high=1000000 - 720 + 1, size=(50, 1))


# In[6]:


arparams = np.array([0.95,])
maparams = np.array([0.,])


# In[7]:


arparams = np.r_[1, -arparams]
maparams = np.r_[1, maparams]
xarma = arma_generate_sample(arparams, maparams, scale=0.001, nsample=1000000, distrvs=rng.normal, burnin=1000)


# In[8]:


def nsb_estimator(bpe: BayesianPermEn, k: int):
    C = bpe._get_all_counts()
    
    n = C.shape[0]
    permen = np.zeros(n)
    std = np.zeros(n)
    for i in range(n):
        c = C[i, :]
        c = c[c > 0] # NSB estimator only considers non-zero frequency counts
        permen[i], std[i] = ndd.entropy(c, k=k, return_std=True)
    
    permen /= math.log(k)
    std /= math.log(k)
    return permen, std


# In[9]:


def perks_estimator(bpe: BayesianPermEn, random_seed: int, k: int, draws: int = 1000):
    C = bpe._get_all_counts()
    a = C + (1 / k) # posterior Dir-Mult concentration parameter
    d = pm.Dirichlet.dist(a)
    pi = pm.draw(d, draws=draws, random_seed=random_seed)

    H = stats.entropy(pi, axis=-1) / math.log(k)
    
    permen = np.mean(H, axis=0)
    std = np.std(H, axis=0)
    return permen, std


# In[10]:


def run_inference(x: np.ndarray, start_idx: np.ndarray, m: int = 5, draws: int = 2000):
    Ns = [10, 20, 30, 40, 50]
    approaches = ['logit-1-1', 'logit-10-2', 'nsb', 'perks']
    iters = np.arange(start_idx.size)
    idx = pd.MultiIndex.from_product([Ns, approaches, iters], names=['N', 'approach', 'iter'])
    out = pd.DataFrame(index=idx, columns=['permen', 'std'])
    out = out.sort_index()

    hyperprior_dict = GAMMA_HYPERPRIOR[m]
    k = math.factorial(m)

    for N in Ns:
        X = x[np.tile(start_idx, reps=N) + np.arange(N)]

        bpe = BayesianPermEn(X, m=m, random_seed=17, draws=draws, return_std=True)
        for approach in approaches:
            if approach == 'logit-1-1':
                alpha, beta = hyperprior_dict[(1, 1)]
                bpe.alpha = alpha
                bpe.beta = beta
                permen, std = bpe.permen()
            elif approach == 'logit-10-2':
                alpha, beta = hyperprior_dict[(10, 2)]
                bpe.alpha = alpha
                bpe.beta = beta
                permen, std = bpe.permen()
            elif approach == 'nsb':
                permen, std = nsb_estimator(bpe, k)
            elif approach == 'perks':
                permen, std = perks_estimator(bpe, random_seed=17, k=k, draws=draws)

            out.loc[(N, approach, slice(None)), 'permen'] = permen
            out.loc[(N, approach, slice(None)), 'std'] = std

    return out


# In[11]:


ar5 = run_inference(xarma, start_idx)


# In[12]:


ar5['sq_dev'] = (ar5['permen'] - ant.perm_entropy(xarma, order=5, normalize=True)) ** 2


# In[13]:


ar5.groupby(['N', 'approach'])['sq_dev'].mean() ** (0.5)


# In[14]:


ar5.groupby(['N', 'approach'])['std'].mean()


# ## Embedding Dimension Size: $m = 6$

# In[15]:


def run_inference6(x: np.ndarray, start_idx: np.ndarray, m: int = 6, draws: int = 2000):
    Ns = [10, 20, 30, 40, 50]
    approaches = ['logit-1-1', 'logit-10-2', 'nsb', 'perks']
    iters = np.arange(start_idx.size)
    idx = pd.MultiIndex.from_product([Ns, approaches, iters], names=['N', 'approach', 'iter'])
    out = pd.DataFrame(index=idx, columns=['permen', 'std'])
    out = out.sort_index()

    hyperprior_dict = GAMMA_HYPERPRIOR[m]
    k = math.factorial(m)

    for N in Ns:
        X = x[np.tile(start_idx, reps=N) + np.arange(N)]

        for i in np.arange(10, 51, 10):
            if i == 10:
                rows = np.arange(i)
            else:
                rows = np.arange((i-10), i)
            Xtmp = X[rows, :]

            bpe = BayesianPermEn(Xtmp, m=m, random_seed=17, draws=draws, return_std=True)
            for approach in approaches:
                if approach == 'logit-1-1':
                    alpha, beta = hyperprior_dict[(1, 1)]
                    bpe.alpha = alpha
                    bpe.beta = beta
                    permen, std = bpe.permen()
                elif approach == 'logit-10-2':
                    alpha, beta = hyperprior_dict[(10, 2)]
                    bpe.alpha = alpha
                    bpe.beta = beta
                    permen, std = bpe.permen()
                elif approach == 'nsb':
                    permen, std = nsb_estimator(bpe, k)
                elif approach == 'perks':
                    permen, std = perks_estimator(bpe, random_seed=17, k=k, draws=draws)
    
                out.loc[(N, approach, rows), 'permen'] = permen
                out.loc[(N, approach, rows), 'std'] = std

    return out


# In[17]:


ar6 = run_inference6(xarma, start_idx, m=6, draws=2000)


# In[18]:


ar6['sq_dev'] = (ar6['permen'] - ant.perm_entropy(xarma, order=6, normalize=True)) ** 2


# In[19]:


ar6.groupby(['N', 'approach'])['sq_dev'].mean() ** (0.5)


# In[20]:


ar6.groupby(['N', 'approach'])['std'].mean()


# In[21]:


ar5.to_csv('../data/results/ar-signal5.csv')


# In[22]:


ar6.to_csv('../data/results/ar-signal6.csv')

