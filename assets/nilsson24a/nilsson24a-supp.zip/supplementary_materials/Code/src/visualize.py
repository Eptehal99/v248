import os
import torch
import pytorch_lightning as pl
from parse_args import parse_args_and_config, create_output_dirs
from pytorch_lightning.loggers.wandb import WandbLogger
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping
import wandb
import numpy as np
import random
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import cv2

import utils
from pl_callbacks import (
    CollateDistributedOutputsCallback,
)
from pl_wrappers import BaselineTrainerWrapper, GumbelTrainerWrapper

import models.gumbel_video_vit as gvvits

MODEL_DICT = {
    **gvvits.__dict__,
}


def update_args(args, config_dict):
    for key, val in config_dict.items():
        setattr(args, key, val)


def patchify(imgs, patch_size, c):
    """
    imgs: (N, 3, H, W)
    patch_size: patch size (int)
    c: number of channels (int)
    Returns:
    x: (N, L, patch_size**2 * c)
    """
    p = patch_size
    assert imgs.shape[2] == imgs.shape[3] and imgs.shape[2] % p == 0

    h = w = imgs.shape[2] // p
    x = imgs.reshape(shape=(imgs.shape[0], c, h, p, w, p))
    x = torch.einsum("nchpwq->nhwpqc", x)
    x = x.reshape(shape=(imgs.shape[0], h * w, p**2 * c))
    return x

def unpatchify(x, patch_size, c):
    """
    x: (N, L, patch_size**2 * 3)
    patch_size: patch size (int)
    c: number of channels (int)
    Returns:
    imgs: (N, 3, H, W)
    """
    p = patch_size
    h = w = int(x.shape[1] ** 0.5)
    assert h * w == x.shape[1]

    x = x.reshape(shape=(x.shape[0], h, w, p, p, c))
    x = torch.einsum("nhwpqc->nchpwq", x)
    imgs = x.reshape(shape=(x.shape[0], c, h * p, h * p))
    return imgs

def mask_videos(videos, patch_size, mask):
    """
    video_images: (batch_size, sequence_length, channels, height, width)
    patch_size: patch size (int)
    mask: (batch_size, sequence_length, num_patches)

    Returns:
    modified_video_images: (batch_size, sequence_length, channels, height, width)
    """
    # Reshape the video images to (batch_size * sequence_length, channels, height, width)
    batch_size, sequence_length, channels, height, width = videos.shape
    reshaped_images = videos.view(-1, channels, height, width)

    # Patchify the images
    patches = patchify(reshaped_images, patch_size, channels)

    # Repeat the mask along the sequence_length dimension
    repeated_mask = mask.repeat(sequence_length, 1)

    grey_patches = patches.clone()
    grey_patches[:] = 255/2
    # Apply the mask to the patches
    masked_patches = patches * repeated_mask.unsqueeze(-1) + grey_patches * (1 - repeated_mask.unsqueeze(-1))

    # Unpatchify the modified patches
    modified_patches = unpatchify(masked_patches, patch_size, channels)

    # Reshape the modified patches back to video format
    modified_video_images = modified_patches.view(
        batch_size, sequence_length, channels, height, width
    )

    return modified_video_images

def imshow_without_borders(image_ndarray, filename):
    """
    Display an image without borders and return the image object.

    Parameters:
    image_ndarray (numpy.ndarray): The image data as a NumPy array.

    Returns:
    matplotlib.image.AxesImage: The image object.
    """
    # sizes = image_ndarray.shape
    c, w, h = image_ndarray.shape
    fig = plt.figure()
    fig.set_size_inches(1. * h / w, 1, forward=False)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)

    cmap = "gray" if c==1 else None
    image_ndarray = np.einsum("chw->hwc", image_ndarray)
    if image_ndarray.shape[-1] == 1:
        image_ndarray = image_ndarray[:, :, 0]
        cmap="gray"
    else:
        cmap=None
    im = ax.imshow(image_ndarray, cmap=cmap)
    fig.savefig(filename, dpi=w, bbox_inches='tight', pad_inches=0)
    plt.close()

def plot_video_as_gif(modified_video, filename='output.gif', fps=10):
    """
    modified_video: (sequence_length, channels, height, width)
    filename: Name of the output GIF file
    fps: Frames per second for the GIF
    """
    # Ensure the input is a PyTorch tensor
    if not torch.is_tensor(modified_video):
        raise ValueError("Input 'modified_video' must be a PyTorch tensor.")
    
    # Convert to numpy array and transpose dimensions for plotting
    frames = modified_video.cpu().numpy()
    s, c, w, h = frames.shape
    # Create the animation
    fig = plt.figure(figsize=(h/100, w/100))  # Adjust the size as needed
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)
    ims = []
    for frame in frames:
        frame = np.einsum("chw->hwc", frame)
        if frame.shape[-1] == 1:
            frame = frame[:, :, 0]
            cmap="gray"
        else:
            cmap=None

        im = ax.imshow(frame, animated=True, cmap=cmap)
        ims.append([im])
    
    ani = animation.ArtistAnimation(fig, ims, interval=1000 // fps, blit=False)
    
    # Save the animation as a GIF
    ani.save(filename, writer='pillow')
    plt.close()

def calculate_average_optical_flow(video_tensor):
    """
    Calculate the average optical flow visualization for a video tensor.

    Parameters:
    video_tensor (numpy.ndarray): Video data as a NumPy array of shape (num_frames, channels, height, width).

    Returns:
    numpy.ndarray: Average optical flow visualization as a NumPy array of shape (height, width, 3).
    """
    num_frames, c, h, w = video_tensor.shape
    video_tensor = video_tensor.cpu().numpy()
    video_tensor = np.einsum("scwh->swhc", video_tensor)
    optical_flow_accumulator = np.zeros((h, w, 2), dtype=np.float32)

    # Calculate optical flow for each pair of consecutive frames
    for i in range(num_frames - 1):
        frame1 = video_tensor[i, :, :, :]  # Use all three channels (RGB)
        frame2 = video_tensor[i + 1, :, :, :]  # Use all three channels (RGB)

        # Calculate optical flow using Farneback method
        flow = cv2.calcOpticalFlowFarneback(
            frame1,  # Convert to grayscale
            frame2,  # Convert to grayscale
            None,
            0.5,
            3,
            15,
            3,
            5,
            1.2,
            0,
        )

        # Accumulate optical flow
        optical_flow_accumulator += flow

    # Calculate the average optical flow
    average_optical_flow = optical_flow_accumulator / (num_frames - 1)

    # Convert optical flow to color-coded visualization
    optical_flow_visualization = flow_to_color(average_optical_flow)

    return optical_flow_visualization

def flow_to_color(flow):
    """
    Convert optical flow to color-coded visualization.

    Parameters:
    flow (numpy.ndarray): Optical flow data as a NumPy array of shape (height, width, 2).

    Returns:
    numpy.ndarray: Color-coded optical flow visualization as a NumPy array of shape (height, width, 3).
    """
    h, w, _ = flow.shape
    hsv = np.zeros((h, w, 3), dtype=np.uint8)

    # Calculate the magnitude and angle of the optical flow
    mag, ang = cv2.cartToPolar(flow[..., 0], flow[..., 1])

    # Map angle to hue value
    hsv[..., 0] = ang * 180 / np.pi / 2

    # Normalize and scale the magnitude for visualization
    hsv[..., 1] = 255
    hsv[..., 2] = cv2.normalize(mag, None, 0, 255, cv2.NORM_MINMAX)

    # Convert HSV to RGB for visualization
    flow_visualization = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)

    return flow_visualization



def main(args):
    print(f"Saving checkpoints in {args.output_dir}")
    print(f"Saving logs in {args.log_dir}")

    callbacks = []

    # Callback for metrics that require all outputs on the split
    callbacks += [CollateDistributedOutputsCallback()]

    datasets = utils.get_EchoNet_train_test_split(args)

    # Define model

    if args.model.startswith("gumbel"):
        model = MODEL_DICT[args.model](
            num_classes=args.num_classes,
            pretrained=args.use_pretrained_enc,
            architecture=args.encoder_arch,
            dim_ctp=args.dim_ctp,
            mask_ratio=args.mask_ratio,
            pi_dropout=args.pi_dropout,
            ctp_dropout=args.ctp_dropout,
            pi_layer_norm=args.pi_layer_norm,
            gumbel_learn_mode=args.gumbel_learn_mode,
        )

        pl_model = GumbelTrainerWrapper(model=model, args=args, datasets=datasets)

    elif args.model.startswith("baseline"):
        model = MODEL_DICT[args.model](
            num_classes=args.num_classes,
            pretrained=args.use_pretrained_enc,
            architecture=args.encoder_arch,
        )

        pl_model = BaselineTrainerWrapper(model=model, args=args, datasets=datasets)
        print(">>> Training with Baseline model")

    # Load a checkpoint
    checkpoint_path = "" #FIXME: load an actual checkpoint here
    if os.path.exists(checkpoint_path):
        checkpoint = torch.load(
            checkpoint_path,
            map_location=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
        )
        pl_model.load_state_dict(checkpoint["state_dict"])
        print("Checkpoint loaded successfully")
    else:
        raise ValueError("Path doesn't exist")

    # Retrieve patchification data
    total_patches = model.encoder.vit.patch_embed.num_patches
    patch_size = model.encoder.vit.patch_embed.patch_size[0]

    img_size = args.input_height
    n_patch_per_side = int(np.sqrt(img_size**2 / patch_size**2))

    # Set the model to evaluation mode
    pl_model.eval()

    # Get the first batch of the training set
    dataloader = pl_model.train_dataloader()
    first_batch = next(iter(dataloader))

    with torch.no_grad():
        # Perform a single forward pass
        inputs, targets = first_batch
        outputs = pl_model(inputs, random=False)
        preds = torch.sigmoid(outputs["logits"])
    pi_raw = outputs["distrib_dict"]["current_pi"]

    num_observed_patches = pi_raw.shape[0]
    _mean = np.array([0.1294])
    _std = np.array([0.1965])

    videos = torch.clip((inputs * _std + _mean) * 255, 0, 255).int()



    # utils.save_pi_snapshot(
    #     pi_raw,
    #     method="multi",
    #     output_dir=args.output_dir,
    #     num_observed_patches=num_observed_patches,
    #     n_patch_per_side=n_patch_per_side,
    #     save_individual_distribs=False,
    # )

    selected_inds = torch.argmax(pi_raw, -1).unsqueeze(0).repeat((inputs.shape[0], 1))
    # #0 is selected, 1 is almost masked
    mask = torch.ones(inputs.shape[0], total_patches)
    mask.scatter_(1, selected_inds.type(torch.int64), 0)

    masked_videos = mask_videos(videos, patch_size, 1 - mask)

    mask_ratio_str = str(args.mask_ratio).replace(".", "_")

    # plt.imshow(masked_videos[0,0,0], cmap="gray")
    # plt.axis('off')
    # plt.savefig()
    # plt.close()
    imshow_without_borders(masked_videos[0,0], os.path.join(args.output_dir, "im1_b1_masked_mr__"+mask_ratio_str+".png"))

    imshow_without_borders(videos[0,0], os.path.join(args.output_dir, "im1_b1_original.png"))
    imshow_without_borders(videos[0,7], os.path.join(args.output_dir, "im1_b1_t_8.png"))
    plot_video_as_gif(masked_videos[0], os.path.join(args.output_dir, "vid1_masked_mr__"+mask_ratio_str+".gif"), fps=25)


    flow = calculate_average_optical_flow(videos[0])
    flow = np.einsum("hwc->chw", flow)
    imshow_without_borders(flow, os.path.join(args.output_dir, "flow.png"))

if __name__ == "__main__":
    # parse args
    args = parse_args_and_config()
    args.output_dir += "mr_" + str(args.mask_ratio).replace(".", "_") + "_"
    create_output_dirs(
        args, is_main_process=utils.get_rank() == 0
    )  # TODO: revisit main process
    # A100 specific setting
    if args.matmul_precision:
        torch.set_float32_matmul_precision(args.matmul_precision)
    # set seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    # run
    main(args)
