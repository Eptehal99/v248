from typing import Any, Optional, Tuple
import pytorch_lightning as pl
import math
from operator import attrgetter
from pytorch_lightning.utilities.types import STEP_OUTPUT
import torch
from pytorch_lightning.utilities.rank_zero import rank_zero_only
from pytorch_lightning.callbacks.early_stopping import EarlyStopping
from torch import Tensor
from deepspeed.profiling.flops_profiler.profiler import FlopsProfiler
from utils import save_pi_snapshot


class TemperatureCallback(pl.Callback):
    """
    Callback to adjust the temperature parameter during training epochs.
    Assumes the PL module has an attribute "temperature"

    Args:
        num_epochs (int): Total number of epochs.
        temp_base (float): Base temperature value.
        temp_min (float): Minimum temperature value.
        stop_anneal (int, optional): Epoch at which to stop annealing. Defaults to 0.
        warmup_epochs (int, optional): Number of warm-up epochs. Defaults to 0.
        mode (str, optional): Annealing mode, either "exp" or "linear". Defaults to "exp".
    """

    def __init__(
        self,
        num_epochs,
        temp_base,
        temp_min,
        stop_anneal=0,
        warmup_epochs=0,
        mode="exp",
    ):
        super().__init__()
        self.num_epochs = num_epochs
        self.temp_base = temp_base
        self.temp_min = temp_min
        self.stop_anneal = stop_anneal
        self.warmup_epochs = warmup_epochs
        self.mode = mode

    def on_train_epoch_start(self, trainer, pl_module):
        epoch = trainer.current_epoch

        if epoch < self.warmup_epochs:
            temp = self.temp_base
        else:
            adj_epoch = epoch - self.warmup_epochs
            adj_num_epochs = self.num_epochs - self.warmup_epochs

            if self.mode == "exp":
                if self.stop_anneal > 0:
                    if adj_epoch > self.stop_anneal:
                        return self.temp_base * (self.temp_min / self.temp_base) ** (
                            self.stop_anneal / adj_num_epochs
                        )
                temp = self.temp_base * (self.temp_min / self.temp_base) ** (
                    adj_epoch / adj_num_epochs
                )
            elif self.mode == "linear":
                k = (self.temp_min - self.temp_base) / (
                    self.num_epochs - self.warmup_epochs
                )
                if self.stop_anneal > 0:
                    if adj_epoch > self.stop_anneal:
                        return k * self.stop_anneal + self.temp_base
                temp = k * adj_epoch + self.temp_base

            temp = max(temp, self.temp_min)
        pl_module.temperature = temp
        # trainer.logger.log_metrics({"temperature": temp}, step=None)


class CosineAnnealLRCallback(pl.Callback):
    """Callback to adjust the learning rate using the cosine annealing schedule with warmup.

    Args:
        lr (float): The initial learning rate.
        min_lr (float): The minimum learning rate.
        warmup_epochs (int): The number of warmup epochs before applying cosine annealing.

    """

    def __init__(self, lr, min_lr, warmup_epochs):
        self.lr = lr
        self.min_lr = min_lr
        self.warmup_epochs = warmup_epochs

    def on_train_epoch_start(self, trainer, pl_module):
        epoch = trainer.current_epoch
        tot_epochs = trainer.max_epochs

        if epoch < self.warmup_epochs:
            lr_temp = self.lr * epoch / self.warmup_epochs
        else:
            lr_temp = self.min_lr + (self.lr - self.min_lr) * 0.5 * (
                1.0
                + math.cos(
                    math.pi
                    * (epoch - self.warmup_epochs)
                    / (tot_epochs - self.warmup_epochs)
                )
            )

        optimizer = trainer.optimizers[0]
        for param_group in optimizer.param_groups:
            if "lr_scale" in param_group:
                param_group["lr"] = lr_temp * param_group["lr_scale"]
            else:
                param_group["lr"] = lr_temp
        pl_module.lr = lr_temp


class FreezeDistribCallback(pl.Callback):
    """Callback to freeze a model's distribution layer for a specified number of epochs.

    Args:
        model: The model containing a distribution layer.
        freeze_distrib (bool): Freeze the distribution permanently.
        freeze_epochs (int): The number of epochs for which the distribution layer should be frozen.

    Returns:
        None
    """

    def __init__(self, model, freeze_distrib=None, freeze_epochs=None):
        super().__init__()
        assert not (
            freeze_distrib and freeze_epochs
        ), "args 'freeze_distrib' and 'freeze_epochs' are incompatible"

        # check if the model has a gumbel distrib
        _err_msg = f"No Gumbel Distribution module was found for {type(model)}. Disable this callback {type(self)}"
        if hasattr(model, "encoder"):
            encoder = getattr(model, "encoder")
            if hasattr(encoder, "feature_select"):
                self._attr = "encoder.feature_select.gumbel_distrib"
            elif hasattr(encoder, "gumbel_distrib"):
                self._attr = "encoder.gumbel_distrib"
            else:
                raise NotImplementedError(_err_msg)
        elif hasattr(model, "feature_select.gumbel_distrib"):
            self._attr = "feature_select.gumbel_distrib"
        elif hasattr(model, "gumbel_distrib"):
            self._attr = "gumbel_disrib"
        else:
            raise NotImplementedError(_err_msg)

        self.attrgetter = attrgetter(self._attr)

        self.freeze_epochs = freeze_epochs

        distrib = self.attrgetter(model)

        if freeze_distrib:
            distrib.freeze(True)

    def on_train_epoch_start(self, trainer, pl_module):
        if self.freeze_epochs is not None:
            distrib = self.attrgetter(pl_module.model)
            distrib.freeze(trainer.current_epoch < self.freeze_epochs)


class CollateDistributedOutputsCallback(pl.Callback):
    """Callback for metrics that require all outputs on the split,
    i.e. cannot be aggregated by average per-batch output such as R²
    """

    def __init__(self):
        super().__init__()

        self.all_val_logits = []
        self.all_val_labels = []

        self.outputs = {
            "train": {"logits": [], "labels": []},
            "val": {"logits": [], "labels": []},
            "test": {"logits": [], "labels": []},
        }

    ### Helper functions for distributed

    def _all_gather_batches(self, trainer, pl_module, tensor):
        if trainer.num_nodes * trainer.num_devices == 1:
            return tensor
        all_tensors = pl_module.all_gather(tensor)
        world_size, batch_size, dims = all_tensors.shape
        return all_tensors.view(-1, *dims)

    def _all_gather_outputs_and_labels(
        self, trainer, pl_module, outputs, batch, split: str
    ):
        returns = outputs["returns"]
        labels = batch[1]
        logits = returns["logits"]
        all_labels = self._all_gather_batches(trainer, pl_module, labels)
        all_logits = self._all_gather_batches(trainer, pl_module, logits)

        self._store_all_batches(all_logits, all_labels, split)

    #### Main process only functions

    @rank_zero_only
    def _store_all_batches(self, all_logits, all_labels, split):
        self.outputs[split]["logits"].extend(all_logits)
        self.outputs[split]["labels"].extend(all_labels)

    @rank_zero_only
    def _calculate_and_log_metrics(self, pl_module, split):
        all_logits = self.outputs[split]["logits"]
        all_labels = self.outputs[split]["labels"]

        # calculate metrics defined in the pl module
        metrics = pl_module._regression_metrics(
            torch.cat(all_logits, dim=0),
            torch.cat(all_labels, dim=0),
        )

        name_suffix = "_full" if pl_module.force_full_input else ""
        stats = {split + "_" + key + name_suffix: val for key, val in metrics.items()}

        # log
        pl_module.log_dict(
            {**stats},
            on_step=False,
            on_epoch=True,
            sync_dist=False,
            rank_zero_only=True,
            # reduce_fx=None,
        )  # sync_dist=True ??

    @rank_zero_only
    def _empty_storage(self, split):
        self.outputs[split] = {"logits": [], "labels": []}

    ### Lightning function overrides

    def on_train_batch_end(
        self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx=0
    ):
        # Gather outputs across processes
        self._all_gather_outputs_and_labels(trainer, pl_module, outputs, batch, "train")

    def on_validation_batch_end(
        self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx=0
    ):
        self._all_gather_outputs_and_labels(trainer, pl_module, outputs, batch, "val")

    def on_test_batch_end(
        self, trainer, pl_module, outputs, batch, batch_idx, dataloader_idx=0
    ):
        self._all_gather_outputs_and_labels(trainer, pl_module, outputs, batch, "test")

    def on_train_epoch_end(self, trainer, pl_module):
        # Calculate metrics on the main process
        self._calculate_and_log_metrics(pl_module, "train")
        # Clear the stored outputs/labels
        self._empty_storage("train")

    def on_validation_epoch_end(self, trainer, pl_module):
        self._calculate_and_log_metrics(pl_module, "val")
        self._empty_storage("val")

    def on_test_epoch_end(self, trainer, pl_module):
        self._calculate_and_log_metrics(pl_module, "test")
        self._empty_storage("test")


# class CustomEarlyStopping(EarlyStopping):
#     def __init__(self, *args, **kwargs):
#         super().__init__(*args, **kwargs)
#         self.is_stopping=False

#     def on_validation_end(self, trainer, pl_module):
#         out = super().on_validation_end(trainer, pl_module)
#         if self.is_stopping:
#             self._log_best_metrics(pl_module)
#         return out

#     @rank_zero_only
#     def _log_best_metrics(self, pl_module):
#         best_metrics = pl_module.tracker.best_metrics
#         pl_module.log_dict(best_metrics)

#     def _evaluate_stopping_criteria(self, current: Tensor):
#         should_stop, reason = super()._evaluate_stopping_criteria(current)
#         self.is_stopping = should_stop
#         return should_stop, reason


class FLOPProfilerCallback(pl.Callback):
    """ Measures the number of FLOPs during the first forward pass on the first batch
    """
    def __init__(self):
        self.profiler = None
        self.measured = False  # To track if profiling has been triggered

    @rank_zero_only
    def on_train_start(self, trainer, pl_module):
        self.profiler = FlopsProfiler(pl_module)

    @rank_zero_only
    def on_train_batch_start(self, trainer, pl_module, batch, batch_idx):
        if not self.measured and trainer.current_epoch == 0 and batch_idx == 0:
            self.profiler.start_profile()

    @rank_zero_only
    def on_train_batch_end(self, trainer, pl_module, outputs, batch, batch_idx):
        if not self.measured and trainer.current_epoch == 0 and batch_idx == 0:
            flops = self.profiler.get_total_flops()
            pl_module.log("FLOPs_inference", float(flops), on_step=True, on_epoch=False)
            self.measured = True  # Mark as measured after profiling first batch
            self.profiler.end_profile()
            self.profiler = None # Delete profiler when done



class CustomSnapshotCallback(pl.Callback):
    def __init__(
        self,
        method,
        output_dir,
        num_observed_patches,
        n_patch_per_side,
        save_individual_distribs=False,
        base_name="",
    ):
        super().__init__()
        self.method = method
        self.output_dir = output_dir
        self.num_observed_patches = num_observed_patches
        self.n_patch_per_side = n_patch_per_side
        self.save_individual_distribs = save_individual_distribs
        self.base_name = base_name

    def on_epoch_end(self, trainer, pl_module):
        pl_module.encoder.feature_selector = ... #FIXME
        save_pi_snapshot(
            self.pi_raw,
            self.method,
            self.output_dir,
            self.num_observed_patches,
            self.n_patch_per_side,
            self.save_individual_distribs,
            self.base_name,
        )

