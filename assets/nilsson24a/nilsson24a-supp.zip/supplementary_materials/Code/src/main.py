import os
import torch
import pytorch_lightning as pl
from parse_args import parse_args_and_config, create_output_dirs
from pytorch_lightning.loggers.wandb import WandbLogger
from pytorch_lightning.callbacks import ModelCheckpoint, EarlyStopping
import wandb
import numpy as np
import random

import utils
from pl_callbacks import (
    FLOPProfilerCallback,
    TemperatureCallback,
    CosineAnnealLRCallback,
    FreezeDistribCallback,
    CollateDistributedOutputsCallback
)
from pl_wrappers import BaselineTrainerWrapper, GumbelTrainerWrapper

import models.gumbel_video_vit as gvvits

MODEL_DICT = {
    **gvvits.__dict__,
}

def update_args(args, config_dict):
    for key, val in config_dict.items():
        setattr(args, key, val)


def main(args):
    print(f"Saving checkpoints in {args.output_dir}")
    print(f"Saving logs in {args.log_dir}")

    # Wandb
    run = None
    logger = None
    if args.wandb and utils.get_rank() == 0:
        run = wandb.init(
            project=args.wandb,
            entity=args.wandb_entity,
            config=vars(args),
            dir=args.output_dir,
        )
        update_args(args, dict(run.config))
        logger = WandbLogger()

    # MAE lr scaling trick
    eff_batch_size = (
        args.batch_size * args.accum_iter * args.num_devices * args.num_nodes
    )
    if args.mae_lr_scaling:
        args.lr = args.blr * eff_batch_size / 256 if args.lr is None else args.lr
    else:
        args.lr = args.blr

    callbacks = []
    # Checkpoint callback
    callbacks += [
        ModelCheckpoint(
            dirpath=args.output_dir,
            filename="{epoch}-{val_loss:.2f}",
            monitor="val_loss",
            mode="min",
            save_top_k=args.save_top_k,
            save_last=args.save_last,
            every_n_epochs=args.every_n_epochs,
        )
    ]
    # Callback for metrics that require all outputs on the split
    callbacks += [CollateDistributedOutputsCallback()]

    if args.anneal_lr and args.optim_mode != "ultraswin":
        # Cosine annealing LR callback
        callbacks += [
            CosineAnnealLRCallback(
                lr=args.lr, min_lr=args.min_lr, warmup_epochs=args.warmup_epochs
            )
        ]
    if args.anneal_temp:
        callbacks += [
            TemperatureCallback(
                num_epochs=args.epochs,
                temp_base=args.temp_base,
                temp_min=args.temp_min,
                stop_anneal=args.stop_anneal,
                # warmup_epochs=args.freeze_epochs,
                mode=args.anneal_temp,
            )
        ]

    # measure FLOPs on the first train batch
    if args.profile_flops:
        callbacks+= [FLOPProfilerCallback()]

    datasets = utils.get_EchoNet_train_test_split(args)

    # Define model

    if args.model.startswith("gumbel"):
        model = MODEL_DICT[args.model](
            num_classes=args.num_classes,
            pretrained=args.use_pretrained_enc,
            architecture=args.encoder_arch,
            dim_ctp=args.dim_ctp,
            mask_ratio=args.mask_ratio,
            pi_dropout=args.pi_dropout,
            ctp_dropout=args.ctp_dropout,
            pi_layer_norm=args.pi_layer_norm,
            gumbel_learn_mode=args.gumbel_learn_mode,
        )

        pl_model = GumbelTrainerWrapper(model=model, args=args, datasets=datasets)

    elif args.model.startswith("baseline"):
        model = MODEL_DICT[args.model](
            num_classes=args.num_classes,
            pretrained=args.use_pretrained_enc,
            architecture=args.encoder_arch,
        )

        pl_model = BaselineTrainerWrapper(model=model, args=args, datasets=datasets)
        print(">>> Training with Baseline model")

    if utils.get_rank() == 0:
        run.log({"num_parameters": utils.get_num_parameters(model)})

    # if args.optim_mode == "finetune":
    #     load_pretrained_encoder(pl_model, args.finetune_path, "gumbelvit")
    # elif args.optim_mode == "linprobe":
    #     load_pretrained_encoder(pl_model, args.finetune_path, "gumbelvit")
    #     for name, param in pl_model.named_parameters():
    #         if "head" not in name:
    #             param.requires_grad = False
    # else:
    #     print("Training from scratch")

    # callback for freezing the gumble distribution
    if args.freeze_distrib or args.freeze_epochs:
        callbacks += [
            FreezeDistribCallback(model, args.freeze_distrib, args.freeze_epochs)
        ]

    if args.early_stop > 0:
        callbacks += [EarlyStopping("val_loss", patience=args.early_stop)]

    # Define trainer
    distributed = args.num_devices > 1 or args.num_nodes > 1
    print(
        f"Starting distributed training using {args.num_devices} devices on {args.num_nodes} node(s)"
    ) if distributed else print("Starting single-device training")

    trainer = pl.Trainer(
        # Distributed kwargs
        accelerator=args.accelerator,
        devices=[i for i in range(args.num_devices)]
        if args.accelerator == "gpu"
        else args.num_devices,
        num_nodes=args.num_nodes,
        strategy=args.strategy if distributed else "auto",
        precision=args.precision,
        # Training args
        max_epochs=args.epochs,
        gradient_clip_val=args.clip_grad,
        logger=logger,
        callbacks=callbacks,
        benchmark=True,
        # profiler="simple"
    )

    trainer.fit(pl_model)
    if args.save_top_k > 0:
        trainer.test(ckpt_path="best")
    
    if args.extra_test_full:
        # extra test epoch on full input using the best model
        pl_model.force_full_input = args.extra_test_full
        trainer.test(ckpt_path="best")

    if args.wandb and utils.get_rank() == 0:
        wandb.finish()


if __name__ == "__main__":
    # parse args
    args = parse_args_and_config()
    create_output_dirs(
        args, is_main_process=utils.get_rank() == 0
    )  # TODO: revisit main process
    # A100 specific setting
    if args.matmul_precision:
        torch.set_float32_matmul_precision(args.matmul_precision)
    # set seed
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    random.seed(args.seed)
    # run
    main(args)
