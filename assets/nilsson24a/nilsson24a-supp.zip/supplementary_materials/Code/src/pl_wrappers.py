import torch
from torch import nn
import pytorch_lightning as pl
from torch.utils.data import DataLoader
import timm.optim.optim_factory as optim_factory
import numpy as np
from torchmetrics import R2Score, MeanSquaredError, MeanAbsoluteError


import utils_finetune


def pad_length_collate_fn(batch):
    sequences, labels = zip(*batch)
    
    # Pad sequences with zeros to match the length of the longest sequence
    padded_sequences = torch.nn.utils.rnn.pad_sequence(sequences, batch_first=True, padding_value=-0.6585)
    
    return padded_sequences, torch.cat(labels)


def fill_masked_patches(x_in, x_pred, masks):
    return x_pred * masks.unsqueeze(-1) + x_in * (1 - masks.unsqueeze(-1))


def calc_classification_metrics(all_outputs, all_targets):
    all_targets = all_targets.detach().cpu().float().numpy()
    all_outputs = all_outputs.detach().cpu().float().numpy()
    # Compute accuracy
    accuracy = accuracy_score(all_targets.argmax(axis=-1), all_outputs.argmax(axis=-1))

    # Compute precision, recall, and F1-score
    precision, recall, f1, _ = precision_recall_fscore_support(
        all_targets.argmax(axis=-1),
        all_outputs.argmax(axis=-1),
        average="weighted",
        zero_division=0,
    )

    # Compute confusion matrix
    # confusion_mat = confusion_matrix(all_targets.argmax(axis=-1), all_outputs.argmax(axis=-1))

    metrics = dict(
        accuracy=accuracy,
        precision=precision,
        recall=recall,
        f1=f1,
        # confusion_mat=confusion_mat,
    )
    return metrics


class BestMetricTracker:
    def __init__(self):
        self.best_metrics = {}
        self.optimization_direction = (
            {}
        )  # Tracks the optimization direction for each metric

    def update_metric(self, name, value, maximize=True):
        if name not in self.best_metrics or self._is_better(
            value, self.best_metrics[name], maximize
        ):
            self.best_metrics[name] = value
            self.optimization_direction[name] = maximize

    def get_best_metric(self, name):
        return self.best_metrics.get(name, None)

    def _is_better(self, new_value, old_value, maximize):
        if maximize:
            return new_value > old_value
        else:
            return new_value < old_value


class GumbelTrainerWrapper(pl.LightningModule):
    """
    PyTorch Lightning module wrapping the GumbelVideoViT model for training.

    This wrapper class provides integration with PyTorch Lightning's train, val and test loop.

    Args:
        model (nn.Module): The VideoViT model instance.
        args (argparse.Namespace): Command-line arguments or a configuration namespace
            containing hyperparameters and settings.
        datasets (list): A list containing the train, val, and test datasets.

    """

    def __init__(self, model, args, datasets):
        super().__init__()

        self.model = model
        self.jsd_factor = args.jsd_factor
        self.temperature = args.temp_base
        self.batch_size = args.batch_size
        self.num_workers = args.num_workers
        self.pin_mem = args.pin_mem
        self.weight_decay = args.weight_decay
        self.datasets = datasets
        self.hard = False  # If True, use Straight-Through Gumbel-Softmax
        self.lr = args.lr
        self.layer_decay = args.layer_decay
        self.mode = args.optim_mode
        self.tracker = BestMetricTracker()
        self.best_metrics_logged = False
        self.force_full_input = False

        loss_type = args.loss_type
        if loss_type == "mse":
            self.loss_fn = nn.MSELoss(reduction="none")
        elif loss_type == "bce":
            self.loss_fn = torch.nn.BCEWithLogitsLoss(reduction="none")
        else:
            raise NotImplementedError(f"Invalid loss func {loss_type} specified")
        self.loss_type = loss_type

        # regression metrics
        self.regression_metrics = True
        self.r2_score = R2Score()
        self.mse_score = MeanSquaredError()
        self.mae_score = MeanAbsoluteError()

    def _regression_metrics(self, all_logits, all_targets):
        all_targets = all_targets.detach()
        all_logits = all_logits.detach()
        all_preds = torch.sigmoid(all_logits)

        metrics = dict(
            r2_score=self.r2_score(all_preds, all_targets).item(),
            rmse_score=torch.sqrt(self.mse_score(all_preds, all_targets)).item(),
            mae_score=self.mae_score(all_preds, all_targets).item(),
        )
        return metrics

    def forward(self, x, **kwargs):
        return self.model(x, bypass_feature_selection=self.force_full_input, **kwargs)

    def _get_input(self, batch):
        imgs, labels = batch
        return imgs, labels

    def _get_losses(self, returns, labels):
        logits = returns["logits"]

        if returns["distrib_dict"] is not None:
            gjsd = returns["distrib_dict"]["GJS"].squeeze(0)
        else:
            gjsd = None

        if self.loss_type == "bce":
            loss = self.loss_fn(logits, labels).mean()
        else:
            preds = torch.sigmoid(logits)
            loss = self.loss_fn(preds, labels).mean()
        return loss, gjsd

    def _get_unique_percentage(self, pi):
        # TODO: should move this to gumbel distrib -> distrib_dict
        _, selected_inds = torch.max(pi, dim=-1)
        num_observed_patches = pi.shape[0]
        unique_inds = np.unique(selected_inds.cpu())
        unique_percentage = len(unique_inds) / num_observed_patches
        return unique_percentage

    def _get_train_stats(self, returns, labels):
        loss, gjsd = self._get_losses(returns, labels)
        if self.jsd_factor > 0:
            loss -= self.jsd_factor * gjsd
        stats = {}
        stats["loss"] = loss

        # metrics = self.calc_regression_metrics(returns["logits"], labels)

        stats = {"train_" + key: val.detach().item() for key, val in stats.items()}
        stats["temperature"] = self.temperature
        stats["gjsd_term"] = gjsd.detach().item()
        return loss, stats

    def _get_eval_stats(self, split, returns, labels):
        loss, _ = self._get_losses(returns, labels)
        # logits = returns["logits"]
        # metrics = calc_classification_metrics(logits, labels)
        metrics = {}
        metrics["loss"] = loss.detach().item()

        name_suffix = "_full" if self.force_full_input else ""
        stats = {split + "_" + key + name_suffix: val for key, val in metrics.items()}
        if split == "val":
            stats["unique_percentage"] = self._get_unique_percentage(
                returns["distrib_dict"]["current_pi"].detach()
            )
        return stats

    def training_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(
            imgs, random=True, temperature=self.temperature, hard=self.hard
        )
        loss, train_stats = self._get_train_stats(returns, labels)
        self.log_dict(
            {**train_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"loss": loss, "returns": returns}

    def validation_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(
            imgs, random=False, temperature=self.temperature, hard=self.hard
        )
        val_stats = self._get_eval_stats("val", returns, labels)
        self.log_dict(
            {**val_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"val_stats": val_stats, "returns": returns}

    def test_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(
            imgs, random=False, temperature=self.temperature, hard=self.hard
        )
        test_stats = self._get_eval_stats("test", returns, labels)
        self.log_dict(
            {**test_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"test_stats": test_stats, "returns": returns}

    def train_dataloader(self):
        return DataLoader(
            self.datasets[0],
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_mem,
            drop_last=True,
            collate_fn=pad_length_collate_fn
        )

    def val_dataloader(self):
        return DataLoader(
            self.datasets[1],
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_mem,
            drop_last=True,
            collate_fn=pad_length_collate_fn
        )

    def test_dataloader(self):
        return DataLoader(
            self.datasets[2],
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            pin_memory=self.pin_mem,
            drop_last=False,
            collate_fn=pad_length_collate_fn
        )

    def configure_optimizers(self):
        if self.layer_decay < 1 and self.layer_decay > 0:
            raise NotImplementedError(
                "Need to redo layerwise LR decay for the new model"
            )
            # build optimizer with layer-wise lr decay (lrd)
            param_groups = utils_finetune.param_groups_lrd(
                self.model,
                self.weight_decay,
                no_weight_decay_list=self.model.no_weight_decay(),
                layer_decay=self.layer_decay,
            )
        else:
            param_groups = optim_factory.param_groups_weight_decay(
                self.model, self.weight_decay
            )

        if self.mode == "finetune":
            return torch.optim.AdamW(param_groups, lr=self.lr, betas=(0.9, 0.9999))
        elif self.mode == "linprobe":
            return torch.optim.SGD(param_groups, lr=self.lr, momentum=0.9)
        elif self.mode == "mae":
            return torch.optim.AdamW(param_groups, lr=self.lr, betas=(0.9, 0.95))
        elif self.mode == "ultraswin":
            optim = torch.optim.AdamW(param_groups, lr=self.lr)
            lr_sched = torch.optim.lr_scheduler.StepLR(optim, step_size=1, gamma=0.85)
            return [optim], [lr_sched]
        else:
            return torch.optim.AdamW(param_groups, lr=self.lr, betas=(0.9, 0.9999))

    def on_validation_epoch_end(self):
        # Get the per-epoch metric value from the logged metrics
        cur_epoch = self.trainer.current_epoch
        if self.global_rank == 0:
            if cur_epoch > 0:
                metrics = self.trainer.logged_metrics
                self.tracker.update_metric(
                    "best_gjsd",
                    metrics["gjsd_term_epoch"].detach().cpu().item(),
                    maximize=True,
                )
                self.tracker.update_metric(
                    "best_val_loss",
                    metrics["val_loss"].detach().cpu().item(),
                    maximize=False,
                )

                ### Special regression metrics
                if self.regression_metrics:
                    self.tracker.update_metric(
                        "best_val_r2_score",
                        metrics["val_r2_score"].detach().cpu().item(),
                        maximize=True,
                    )

                    self.tracker.update_metric(
                        "best_val_rmse_score",
                        metrics["val_rmse_score"].detach().cpu().item(),
                        maximize=False,
                    )

                    self.tracker.update_metric(
                        "best_val_mae_score",
                        metrics["val_mae_score"].detach().cpu().item(),
                        maximize=False,
                    )

            if cur_epoch == self.trainer.max_epochs - 1:
                self.log_dict(self.tracker.best_metrics)
                self.best_metrics_logged = True

    def on_train_epoch_end(self):
        optimizer = self.optimizers()
        current_lr = optimizer.param_groups[0]["lr"]
        self.log("lr", current_lr, on_step=False, on_epoch=True)

    def on_train_end(self):
        if not self.best_metrics_logged:
            self.logger.experiment.log(self.tracker.best_metrics)


class BaselineTrainerWrapper(GumbelTrainerWrapper):
    def __init__(self, model, args, datasets):
        super().__init__(model, args, datasets)
        del self.jsd_factor
        del self.temperature
        del self.hard
        self.mask_ratio = args.mask_ratio

    def _get_losses(self, returns, labels):
        logits = returns["logits"]
        if self.loss_type == "bce":
            loss = self.loss_fn(logits, labels).mean()
        else:
            preds = torch.sigmoid(logits)
            loss = self.loss_fn(preds, labels).mean()
        return loss

    def _get_train_stats(self, returns, labels):
        loss = self._get_losses(returns, labels)
        stats = {}
        stats["loss"] = loss

        stats = {"train_" + key: val.detach().item() for key, val in stats.items()}
        return loss, stats

    def _get_eval_stats(self, split, returns, labels):
        loss = self._get_losses(returns, labels)
        metrics = {}
        metrics["loss"] = loss.detach().item()
        name_suffix = "_full" if self.force_full_input else ""
        stats = {split + "_" + key + name_suffix: val for key, val in metrics.items()}
        return stats

    def training_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(imgs, mask_ratio=self.mask_ratio)
        loss, train_stats = self._get_train_stats(returns, labels)
        self.log_dict(
            {**train_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"loss": loss, "returns": returns}

    def validation_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(imgs, mask_ratio=self.mask_ratio)
        val_stats = self._get_eval_stats("val", returns, labels)
        self.log_dict(
            {**val_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"val_stats": val_stats, "returns": returns}

    def test_step(self, batch, batch_idx):
        imgs, labels = self._get_input(batch)
        returns = self.forward(imgs, mask_ratio=self.mask_ratio)
        test_stats = self._get_eval_stats("test", returns, labels)
        self.log_dict(
            {**test_stats}, on_epoch=True, batch_size=imgs.shape[0], sync_dist=True
        )
        return {"test_stats": test_stats, "returns": returns}

    def on_validation_epoch_end(self):
        # Get the per-epoch metric value from the logged metrics
        cur_epoch = self.trainer.current_epoch
        if self.global_rank == 0:
            if cur_epoch > 0:
                metrics = self.trainer.logged_metrics

                self.tracker.update_metric(
                    "best_val_loss",
                    metrics["val_loss"].detach().cpu().item(),
                    maximize=False,
                )

                ### Special regression metrics
                if self.regression_metrics:
                    self.tracker.update_metric(
                        "best_val_r2_score",
                        metrics["val_r2_score"].detach().cpu().item(),
                        maximize=True,
                    )

                    self.tracker.update_metric(
                        "best_val_rmse_score",
                        metrics["val_rmse_score"].detach().cpu().item(),
                        maximize=False,
                    )

                    self.tracker.update_metric(
                        "best_val_mae_score",
                        metrics["val_mae_score"].detach().cpu().item(),
                        maximize=False,
                    )
