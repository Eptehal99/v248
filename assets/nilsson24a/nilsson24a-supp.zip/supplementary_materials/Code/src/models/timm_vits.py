#!/usr/bin/env python
# -*-coding:utf-8 -*-
"""
@File    :   timm_vits.py
@Time    :   2023/08/11
@Author  :   Anonymous
@Contact :   Anonymous
@Desc    :   Custom ViT class inheriting from timm.models.vision_transformer.py to keep all pretrained weights (down)loading functionality
                reference: https://github.com/huggingface/pytorch-image-models/blob/main/timm/models/vision_transformer.py
"""

from functools import partial
from typing import Any, Callable, Optional, Tuple, Union
from timm.layers import Mlp, PatchEmbed
from timm.models.vision_transformer import (
    Block,
    VisionTransformer,
    checkpoint_filter_fn,
    build_model_with_cfg,
    checkpoint_seq,
)
import torch
import pytorch_lightning as pl
import torch.nn as nn

from models.patch_selector import VideoPatchSelector


class CustomTimmViT(VisionTransformer):
    def __init__(
        self,
        # timm kwargs
        img_size=224,
        patch_size=16,
        in_chans: int = 3,
        num_classes: int = 1000,
        global_pool: str = "token",
        embed_dim: int = 768,
        depth: int = 12,
        num_heads: int = 12,
        mlp_ratio: float = 4,
        qkv_bias: bool = True,
        qk_norm: bool = False,
        init_values=None,
        class_token: bool = True,
        no_embed_class: bool = False,
        pre_norm: bool = False,
        fc_norm=None,
        drop_rate: float = 0,
        pos_drop_rate: float = 0,
        patch_drop_rate: float = 0,
        proj_drop_rate: float = 0,
        attn_drop_rate: float = 0,
        drop_path_rate: float = 0,
        weight_init: str = "",
        embed_layer: Callable = PatchEmbed,
        norm_layer=None,
        act_layer=None,
        block_fn: Callable = Block,
        mlp_layer: Callable = Mlp,
        # own kwargs
    ):
        super().__init__(
            img_size,
            patch_size,
            in_chans,
            num_classes,
            global_pool,
            embed_dim,
            depth,
            num_heads,
            mlp_ratio,
            qkv_bias,
            qk_norm,
            init_values,
            class_token,
            no_embed_class,
            pre_norm,
            fc_norm,
            drop_rate,
            pos_drop_rate,
            patch_drop_rate,
            proj_drop_rate,
            attn_drop_rate,
            drop_path_rate,
            weight_init,
            embed_layer,
            norm_layer,
            act_layer,
            block_fn,
            mlp_layer,
        )

    def _patch_and_pos_embed(self, x):
        x = self.patch_embed(x)
        x = self._pos_embed(x)
        return x

    def _forward_blocks(self, x):
        x = self.norm_pre(x)
        if self.grad_checkpointing and not torch.jit.is_scripting():
            x = checkpoint_seq(self.blocks, x)
        else:
            x = self.blocks(x)
        x = self.norm(x)
        return x

    def _forward_final(self, x):
        if self.global_pool:
            x = (
                x[:, self.num_prefix_tokens :].mean(dim=1)
                if self.global_pool == "avg"
                else x[:, 0]
            )
        return x

    def forward(self, x):
        x = self._patch_and_pos_embed(x)
        x = self._forward_blocks(x)
        x = self._forward_final(x)
        return x


class FrameEncoderViT(pl.LightningModule):
    def __init__(
        self,
        architecture="vit_tiny_patch16_224",
        img_size=112,
        color_channels=1,
        pretrained=True,
        output_dim=None,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
    ):
        super().__init__()

        load_fn = globals()[architecture]

        self.vit = load_fn(
            pretrained=pretrained,
            img_size=img_size,
            in_chans=color_channels,
            num_classes=0,
        )

        proj = nn.Identity()
        if output_dim is not None and self.vit.embed_dim != output_dim:
            # final projection
            proj = nn.Sequential(
                norm_layer(self.vit.embed_dim),
                nn.Linear(self.vit.embed_dim, output_dim),
            )
        self.proj = proj

    def _get_dims(self, imgs):
        N = imgs.shape[0]
        S = imgs.shape[1]
        C = imgs.shape[2]
        H = imgs.shape[3]
        W = imgs.shape[4]
        return N, S, C, H, W
    
    def forward(self, imgs, mask_ratio=0, bypass_feature_selection=False, **kwargs):
        N, S, C, H, W = self._get_dims(imgs)
        imgs = imgs.view((N * S, C, H, W))
        x = self.vit._patch_and_pos_embed(imgs)
        L, D = x.shape[1], x.shape[2]  # L is actually length + 1 (cls)

        if mask_ratio > 0 and not bypass_feature_selection:
            # pop cls token
            x = x.view((N, S, L, D))
            x_without_cls = x[:, :, self.vit.num_prefix_tokens :, :]
            cls = x[:, :, :1, :]
            
            x_without_cls = x_without_cls.view((N*S, L-self.vit.num_prefix_tokens, D))
            # mask
            x_subset = self.random_masking(x_without_cls, mask_ratio)
            num_obs_patches = x_subset.shape[1]

            x_subset = x_subset.view((N, S, num_obs_patches, D))

            # add back cls token
            x_subset = torch.cat((cls, x_subset), dim=2)
            x_subset = x_subset.view((N * S, num_obs_patches + 1, D))
        else:
            x_subset = x

        x = self.vit._forward_blocks(x_subset)
        x = self.vit._forward_final(x)
        z = self.proj(x)

        feature_dim = z.shape[-1]
        z = z.view((N, S, feature_dim))
        return z

    def random_masking(self, x, mask_ratio):
        """
        Perform per-sample random masking by per-sample shuffling.
        Per-sample shuffling is done by argsort random noise.
        x: [N, L, D], sequence
        """
        N, L, D = x.shape  # batch, length, dim
        len_keep = int(L * (1 - mask_ratio))

        noise = torch.rand(N, L, device=self.device)  # noise in [0, 1]

        # sort noise for each sample
        ids_shuffle = torch.argsort(noise, dim=1)

        # keep the first subset
        ids_keep = ids_shuffle[:, :len_keep]
        x_masked = torch.gather(x, dim=1, index=ids_keep.unsqueeze(-1).repeat(1, 1, D))

        return x_masked


class GumbelFrameEncoderViT(FrameEncoderViT):
    def __init__(
        self,
        architecture="vit_tiny_patch16_224",
        img_size=112,
        color_channels=1,
        pretrained=True,
        output_dim=None,
        norm_layer=partial(nn.LayerNorm, eps=0.000001),
        gumbel_kwargs: dict = {},
    ):
        super().__init__(
            architecture, img_size, color_channels, pretrained, output_dim, norm_layer
        )

        self.patch_selector = VideoPatchSelector(
            num_patches=self.vit.patch_embed.num_patches, **gumbel_kwargs
        )

    def _patch_and_pos_embed(self, imgs):
        return self.vit._patch_and_pos_embed(imgs)

    def _forward_encode(self, x):
        x = self.vit._forward_blocks(x)
        x = self.vit._forward_final(x)
        return self.proj(x)

    def _get_dims(self, imgs):
        N = imgs.shape[0]
        S = imgs.shape[1]
        C = imgs.shape[2]
        H = imgs.shape[3]
        W = imgs.shape[4]
        return N, S, C, H, W

    def forward(
        self,
        imgs,
        random,
        temperature=1.0,
        hard=False,
        bypass_feature_selection=False,
        **kwargs,
    ):
        """
        imgs: (N, S, C, H, W)
        """
        if bypass_feature_selection:
            assert (
                not self.training
            ), "Can only bypass the Gumbel distributions in eval mode"

        N, S, C, H, W = self._get_dims(imgs)
        imgs = imgs.view((N * S, C, H, W))

        # patchify/embed
        x = self._patch_and_pos_embed(imgs)
        L, D = x.shape[1], x.shape[2]  # L is actually length + 1 (cls)

        if not bypass_feature_selection:  # select patches
            # pop cls token
            x = x.view((N, S, L, D))
            x_without_cls = x[:, :, self.vit.num_prefix_tokens :, :]
            cls = x[:, :, :1, :]

            x_subset, distrib_dict = self.patch_selector(
                x_without_cls, random, temperature, hard
            )  # (N, S, num_obs_patches, D)
            num_obs_patches = x_subset.shape[2]

            # add back cls token
            x_subset = torch.cat((cls, x_subset), dim=2)

            # encode each frame
            x_subset = x_subset.view((N * S, num_obs_patches + 1, D))

        else:
            x_subset = x
            distrib_dict = None

        z = self._forward_encode(x_subset)  # (N*S, feature_dim)
        feature_dim = z.shape[-1]
        z = z.view((N, S, feature_dim))
        return z, distrib_dict


def _create_vision_transformer(variant, pretrained=False, **kwargs):
    if kwargs.get("features_only", None):
        raise RuntimeError(
            "features_only not implemented for Vision Transformer models."
        )

    if "flexi" in variant:
        # FIXME Google FlexiViT pretrained models have a strong preference for bilinear patch / embed
        # interpolation, other pretrained models resize better w/ anti-aliased bicubic interpolation.
        _filter_fn = partial(
            checkpoint_filter_fn, interpolation="bilinear", antialias=False
        )
    else:
        _filter_fn = checkpoint_filter_fn

    return build_model_with_cfg(
        CustomTimmViT,
        variant,
        pretrained,
        pretrained_filter_fn=_filter_fn,
        **kwargs,
    )


def vit_tiny_patch16_224(pretrained=False, **kwargs) -> CustomTimmViT:
    """ViT-Tiny (Vit-Ti/16)"""
    model_args = dict(patch_size=16, embed_dim=192, depth=12, num_heads=3)
    model = _create_vision_transformer(
        "vit_tiny_patch16_224", pretrained=pretrained, **dict(model_args, **kwargs)
    )
    return model


def vit_small_patch14_dinov2(pretrained=False, **kwargs) -> VisionTransformer:
    """ViT-S/14 for DINOv2"""
    model_args = dict(
        patch_size=14,
        embed_dim=384,
        depth=12,
        num_heads=6,
        init_values=1e-5,
        img_size=518,
    )
    model = _create_vision_transformer(
        "vit_small_patch14_dinov2", pretrained=pretrained, **dict(model_args, **kwargs)
    )
    return model


if __name__ == "__main__":
    # model = vit_tiny_patch16_224(
    #     pretrained=True, in_chans=1, img_size=112, num_classes=0
    # )
    model = FrameEncoderViT(output_dim=412, architecture="vit_small_patch14_dinov2")
    inp = torch.randn((1, 1, 112, 112))
    print(model(inp).shape)
    bp = 0
