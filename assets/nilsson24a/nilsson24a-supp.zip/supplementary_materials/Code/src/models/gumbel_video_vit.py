#!/usr/bin/env python
# -*-coding:utf-8 -*-
"""
@File    :   gumbel_video_vit.py
@Time    :   2023/08/01
@Author  :   Anonymous
@Contact :   Anonymous
@Desc    :   ViT + Sequence Transformer video models
"""


from typing import Any
import torch
import torch.nn as nn
import pytorch_lightning as pl
from functools import partial
from timm.models.vision_transformer import PatchEmbed


from models.timeseries_transformer import TimeSeriesTransformer
from models.timm_vits import GumbelFrameEncoderViT, FrameEncoderViT


class VideoViT(pl.LightningModule):
    """Baseline ViT + Sequence Transformer video model (without feature selection)"""

    def __init__(
        self,
        num_classes=1,
        # timm vit encoder args
        architecture="vit_tiny_patch16_224",
        pretrained=False,
        # data args
        img_size=112,
        color_channels=1,
        # dimension of feature vectors
        feature_dim=256,
        # sequence model args
        max_sequence_len=16,
        seq_depth=8,
        seq_num_heads=8,
        seq_mlp_ratio=4,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        head="mlp",
    ):
        super().__init__()

        encoder_kwargs = dict(
            architecture=architecture,
            pretrained=pretrained,
            img_size=img_size,
            color_channels=color_channels,
            output_dim=feature_dim,
        )
        self._create_encoder(encoder_kwargs)

        self.feature_dim = (
            feature_dim if feature_dim is not None else self.encoder.vit.embed_dim
        )

        self.seq_model = TimeSeriesTransformer(
            max_sequence_len=max_sequence_len,
            embed_dim=self.feature_dim,
            depth=seq_depth,
            num_heads=seq_num_heads,
            mlp_ratio=seq_mlp_ratio,
            global_pool=False,
            norm_layer=norm_layer,
        )

        if head == "linear":
            self.head = nn.Sequential(
                norm_layer(self.feature_dim), nn.Linear(self.feature_dim, num_classes)
            )
        elif head == "mlp":
            self.head = nn.Sequential(
                nn.LayerNorm(self.feature_dim),
                nn.Linear(
                    in_features=self.feature_dim,
                    out_features=self.feature_dim // 2,
                    bias=True,
                ),
                nn.LeakyReLU(negative_slope=0.05),
                nn.LayerNorm(self.feature_dim // 2),
                nn.Linear(
                    in_features=self.feature_dim // 2,
                    out_features=self.feature_dim // 4,
                    bias=True,
                ),
                nn.LeakyReLU(negative_slope=0.05),
                nn.LayerNorm(self.feature_dim // 4),
                # nn.LeakyReLU(negative_slope=0.05),
                nn.Linear(
                    in_features=self.feature_dim // 4,
                    out_features=num_classes,
                    bias=True,
                ),
            )
        else:
            ValueError(f"Invalid head type: '{head}'")

    def _create_encoder(self, kwargs: dict):
        self.encoder = FrameEncoderViT(**kwargs)

    def _get_dims(self, imgs):
        N = imgs.shape[0]
        S = imgs.shape[1]
        C = imgs.shape[2]
        H = imgs.shape[3]
        W = imgs.shape[4]
        return N, S, C, H, W

    def forward(self, imgs, mask_ratio=0, bypass_feature_selection=False, **kwargs):
        """
        imgs: (N, S, C, H, W)
        """

        # embed patches
        N, S, C, H, W = self._get_dims(imgs)

        z = self.encoder(
            imgs, mask_ratio, bypass_feature_selection=bypass_feature_selection
        )  # (N, S, feature_dim)

        w = self.seq_model(z)  # (N, feature_dim)

        logits = self.head(w)  # (N, num_classes)

        return {"logits": logits}


class GumbelVideoViT(pl.LightningModule):
    """Baseline ViT + Sequence Transformer video model and learned patch selections using Gumbel-Softmax distributions"""

    def __init__(
        self,
        num_classes=1,
        # timm vit encoder args
        architecture="vit_tiny_patch16_224",
        pretrained=False,
        # data args
        img_size=112,
        color_channels=1,
        # dimension of feature vectors
        feature_dim=256,
        # sequence model args
        max_sequence_len=16,
        seq_depth=8,
        seq_num_heads=8,
        seq_mlp_ratio=4,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        head="mlp",
        # gumbel arguments
        mask_ratio=0.2,
        dim_ctp=0,
        pi_dropout=0,
        ctp_dropout=0,
        pi_layer_norm=False,
        gumbel_learn_mode="pi",
    ):
        super().__init__()

        encoder_kwargs = dict(
            architecture=architecture,
            pretrained=pretrained,
            img_size=img_size,
            color_channels=color_channels,
            output_dim=feature_dim,
        )

        gumbel_kwargs = dict(
            mask_ratio=mask_ratio,
            dim_ctp=dim_ctp,
            pi_dropout=pi_dropout,
            ctp_dropout=ctp_dropout,
            pi_layer_norm=pi_layer_norm,
            gumbel_learn_mode=gumbel_learn_mode,
        )

        self._create_encoder(encoder_kwargs, gumbel_kwargs)

        self.feature_dim = (
            feature_dim if feature_dim is not None else self.encoder.vit.embed_dim
        )

        self.seq_model = TimeSeriesTransformer(
            max_sequence_len=max_sequence_len,
            embed_dim=self.feature_dim,
            depth=seq_depth,
            num_heads=seq_num_heads,
            mlp_ratio=seq_mlp_ratio,
            global_pool=False,
            norm_layer=norm_layer,
        )

        if head == "linear":
            self.head = nn.Sequential(
                norm_layer(self.feature_dim), nn.Linear(self.feature_dim, num_classes)
            )
        elif head == "mlp":
            self.head = nn.Sequential(
                nn.LayerNorm(self.feature_dim),
                nn.Linear(
                    in_features=self.feature_dim,
                    out_features=self.feature_dim // 2,
                    bias=True,
                ),
                nn.LeakyReLU(negative_slope=0.05),
                nn.LayerNorm(self.feature_dim // 2),
                nn.Linear(
                    in_features=self.feature_dim // 2,
                    out_features=self.feature_dim // 4,
                    bias=True,
                ),
                nn.LeakyReLU(negative_slope=0.05),
                nn.LayerNorm(self.feature_dim // 4),
                # nn.LeakyReLU(negative_slope=0.05),
                nn.Linear(
                    in_features=self.feature_dim // 4,
                    out_features=num_classes,
                    bias=True,
                ),
            )
        else:
            ValueError(f"Invalid head type: '{head}'")

    def _create_encoder(self, encoder_kwargs: dict, gumbel_kwargs: dict):
        self.encoder = GumbelFrameEncoderViT(
            **encoder_kwargs, gumbel_kwargs=gumbel_kwargs
        )

    def forward(
        self,
        imgs,
        random,
        temperature=1.0,
        hard=False,
        bypass_feature_selection=False,
        **kwargs,
    ):
        """
        imgs: (N, S, C, H, W)
        """

        z, distrib_dict = self.encoder(
            imgs,
            random,
            temperature,
            hard,
            bypass_feature_selection=bypass_feature_selection,
        )

        w = self.seq_model(z)  # (N, feature_dim)
        logits = self.head(w)  # (N, num_classes)

        return {"logits": logits, "distrib_dict": distrib_dict}


def baseline_timm_base(
    num_classes=1, pretrained=False, architecture="vit_small_patch14_dinov2", **kwargs
):
    # medium sequence model, embed dim of ViT enc unchanged
    return VideoViT(
        num_classes=num_classes,
        # timm enc args
        architecture=architecture,
        pretrained=pretrained,
        # data args
        img_size=112,
        color_channels=1,
        # dimension of feature vectors
        feature_dim=None,
        # sequence model args
        max_sequence_len=64,
        seq_depth=5,
        seq_num_heads=8,
        seq_mlp_ratio=4,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        # head
        head="linear",
    )


def gumbel_timm_base(
    num_classes=1, pretrained=False, architecture="vit_small_patch14_dinov2", **kwargs
):
    # medium sequence model, embed dim of ViT enc unchanged
    return GumbelVideoViT(
        num_classes=num_classes,
        # timm enc args
        architecture=architecture,
        pretrained=pretrained,
        # data args
        img_size=112,
        color_channels=1,
        # dimension of feature vectors
        feature_dim=None,
        # sequence model args
        max_sequence_len=64,
        seq_depth=5,
        seq_num_heads=8,
        seq_mlp_ratio=4,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
        # head
        head="linear",
        # gumbel kwargs
        **kwargs,
    )


if __name__ == "__main__":
    from utils import get_num_parameters

    test_im = torch.randn((10, 16, 1, 112, 112))
    mask_ratio = 0.2
    dim_ctp = 0
    model_gumbel = gumbel_timm_base(mask_ratio=1)
    print(f"model_gumbel: {get_num_parameters(model_gumbel):.3e} params")
    outs = model_gumbel(test_im, True)
    print(outs["logits"].shape)
