import torch
import torch.nn as nn
import pytorch_lightning as pl
import torch.nn.functional as F
from torch.autograd import Function
import numpy as np
import time


class PiWithCTP(pl.LightningModule):
    def __init__(
        self,
        num_categories,
        dim_ctp,
        num_ctp,
        marginal_initialization="random",
        dropout=0,
        mlp_dropout=0,
        hiddens=[],
        norm_layer=nn.LayerNorm,
    ):
        super().__init__()
        P_init = torch.eye(dim_ctp, requires_grad=True)[:num_ctp]
        self.psudeo_inputs = nn.Parameter(P_init)  # num_ctp x dim_ctp

        net_dims = [dim_ctp] + hiddens + [num_categories]
        nets = []

        for i in range(len(net_dims) - 1):
            nets += [nn.Linear(net_dims[i], net_dims[i + 1])]
            if i < len(net_dims) - 2:
                if norm_layer is not None:
                    nets += [norm_layer(net_dims[i + 1])]
                nets += [nn.ReLU()]
                nets += [nn.Dropout(mlp_dropout)]
        self.weights = nn.Sequential(*nets)

        if marginal_initialization == "uniform" and not hiddens:
            pi_init = torch.ones([num_ctp, num_categories]) / num_categories
            P_inv = np.linalg.pinv(P_init.detach())
            W_init = torch.tensor(
                np.dot(P_inv, pi_init).transpose(), requires_grad=True
            )
            self.weights[0].weight = nn.Parameter(W_init)
            nn.init.constant_(self.weights[0].bias, 0)
        self.dropout = nn.Dropout(dropout)

    def forward(self, eps=1e-8):
        # num_ctp x num_categories
        pi_raw = self.weights(self.dropout(self.psudeo_inputs))
        return pi_raw


class GumbelDistribution(pl.LightningModule):
    def __init__(
        self,
        num_categories,
        marginal_initialization="uniform",
        num_distributions=1,
        dim_ctp=0,
        pi_dropout=0,
        ctp_dropout=0,
        layer_norm=False,
        shared_weights=True,
        ctp_hiddens=[],
    ):
        super().__init__()
        self.num_categories = num_categories
        self.num_distributions = num_distributions
        self.dim_ctp = dim_ctp

        ctp_args = dict(
            num_categories=num_categories,
            dim_ctp=dim_ctp,
            num_ctp=num_distributions,
            marginal_initialization=marginal_initialization,
            dropout=ctp_dropout,
            hiddens=ctp_hiddens,
        )
        if dim_ctp > 0:
            self.pi_marginal = PiWithCTP(**ctp_args)

        else:
            if marginal_initialization == "uniform":
                prior = (
                    torch.ones([num_distributions, num_categories], requires_grad=True)
                    / num_categories
                )
            elif marginal_initialization == "random":
                prior = torch.rand(
                    [num_distributions, num_categories], requires_grad=True
                )
                prior = prior / prior.sum(dim=1).unsqueeze(1)
            else:
                raise NotImplementedError

            self.pi_marginal = nn.Parameter(prior)

        self.pi_dropout = nn.Dropout(pi_dropout)

        if layer_norm:
            self.pi_layernorm = nn.LayerNorm((num_distributions, num_categories))
        else:
            self.pi_layernorm = None
        self.frozen = False

    def freeze(self, freeze: bool):
        for param in self.parameters():
            param.requires_grad = not freeze
        self.frozen = freeze

    def get_pi(self, eps):
        if self.dim_ctp > 0:
            pi_raw = self.pi_marginal()
        else:
            pi_raw = self.pi_marginal

        if self.pi_layernorm:
            pi_raw = self.pi_layernorm(pi_raw)
        else:
            pi_raw = pi_raw

        pi = self.pi_dropout(pi_raw)
        pi = pi**2 + eps
        pi = pi / (pi.sum(dim=1).unsqueeze(1))  # sum to 1
        logits = torch.log(pi)
        return pi, logits, pi_raw

    def batch_sample_joint(
        self,
        num_batches,
        temperature,
        random,
        rao_samples=1,
        eps=1e-4,
        hard=False,
        ret_GJS=True,
        temp_jsd=None,
    ):

        pi, logits, pi_raw = self.get_pi(eps=eps)

        distrib_dict = {"num_categories": pi.shape[1], "current_pi": pi}
        if ret_GJS:
            if temp_jsd is None:  # tempered GJS
                gjs = self.GJS_divergence(pi, temp_jsd)
            else:
                gjs = self.GJS_divergence(pi_raw, temp_jsd)
            distrib_dict["GJS"] = gjs

        if not random:
            pi_deterministic = torch.zeros(pi.shape)
            observed_inds = torch.argmax(pi, dim=1)
            num_distrib, num_cat = pi.shape
            pi_deterministic[torch.arange(num_distrib), observed_inds] = 1
            batch_sampler = pi_deterministic.expand([num_batches, num_distrib, num_cat])
            batch_sampler = batch_sampler.type_as(pi)

        else:
            logits = logits.unsqueeze(0).repeat(num_batches, 1, 1)
            batch_sampler = F.gumbel_softmax(logits, temperature, hard=hard)

        return batch_sampler, distrib_dict

    def GJS_divergence(self, pi, temp_jsd=None):

        if temp_jsd is not None:
            pi = F.softmax(pi / temp_jsd, dim=-1)

        # pi.shape = num_distrib x num_patches = M x C
        M = self.num_distributions
        # w = mixture_weights
        w = torch.ones([M, 1]).type_as(pi) / M

        d_gls = torch.sum(
            w
            * torch.sum(
                pi
                * (torch.log(pi) - torch.log(torch.sum(w * pi, dim=0).repeat([M, 1]))),
                dim=1,
                keepdim=True,
            ),
            dim=0,
        )
        return d_gls


class GumbelDistributionLogits(GumbelDistribution):
    def get_logits(self):
        if self.dim_ctp > 0:
            logits_raw = self.pi_marginal()
        else:
            logits_raw = self.pi_marginal

        if self.pi_layernorm:
            logits = self.pi_layernorm(logits_raw)
        else:
            logits = logits_raw
        return logits

    def get_pi(self, eps):
        logits = self.get_logits()
        logits = self.pi_dropout(logits)
        pi = F.softmax(logits, dim=1)
        return pi, logits, logits


class GumbelDistributionSoftmaxAct(GumbelDistribution):
    def get_pi(self, eps):
        if self.dim_ctp > 0:
            pi_raw = self.pi_marginal()
        else:
            pi_raw = self.pi_marginal

        if self.pi_layernorm:
            pi_raw = self.pi_layernorm(pi_raw)

        pi = self.pi_dropout(pi_raw)
        pi = F.softmax(pi, dim=1)
        logits = torch.log(pi + 1e-8)
        return pi, logits, pi_raw


class GumbelDistributionBijectiveSoftmax(GumbelDistribution):
    def __init__(
        self,
        num_categories,
        marginal_initialization="uniform",
        num_distributions=1,
        dim_ctp=0,
        pi_dropout=0,
        ctp_dropout=0,
        layer_norm=False,
        shared_weights=True,
    ):
        super().__init__(
            num_categories - 1,
            marginal_initialization,
            num_distributions,
            dim_ctp,
            pi_dropout,
            ctp_dropout,
            layer_norm,
            shared_weights,
        )

    def get_pi(self, eps):
        if self.dim_ctp > 0:
            pi_raw = self.pi_marginal()
        else:
            pi_raw = self.pi_marginal

        if self.pi_layernorm:
            pi_raw = self.pi_layernorm(pi_raw)

        pi_raw = self.pi_dropout(pi_raw)

        x_pad = torch.nn.functional.pad(pi_raw, pad=(0, 1, 0, 0), value=0.0)
        pi = torch.nn.functional.softmax(x_pad, dim=-1)

        logits = torch.log(pi + 1e-8)
        return pi, logits, pi_raw

    def invert_pi(self, pi_normalized):
        x = torch.log(pi_normalized)
        x, log_normalization = torch.split(x, [self.num_categories, 1], dim=-1)
        logits_recovered = x - log_normalization
        return logits_recovered


if __name__ == "__main__":
    from utils import get_num_parameters

    device = torch.device("cuda") if torch.cuda.is_available() else torch.device("cpu")
    random = True
    marginal_initialization = "random"

    img_size = 28
    patch_size = 2
    mask_ratio = 0.9

    num_patches = int(img_size**2 / patch_size**2)
    assert img_size**2 / patch_size**2 % 1 == 0
    num_obs = int((1 - mask_ratio) * num_patches)

    num_batches = 1
    num_distributions = num_obs
    dim_ctp = 150
    ctp_hiddens = [78, 78, 78]
    ctp_hiddens = [100]
    ctp_hiddens = []
    rao_samples = 0
    hard = False
    freeze = True
    shared_weights = False

    print("------------------------------JOINT----------------------------")
    distrib = GumbelDistributionBijectiveSoftmax(
        num_patches,
        num_distributions=num_distributions,
        marginal_initialization=marginal_initialization,
        dim_ctp=dim_ctp,
        shared_weights=shared_weights,
    ).to(device)
    distrib.freeze(freeze)
    pi = distrib.pi_marginal
    print(pi)
    print(pi.shape)
    print(pi.sum(dim=1))
    batch_sampler = distrib.batch_sample_joint(
        num_batches, 1.0, random=random, hard=hard, rao_samples=rao_samples
    )
    sampler_first_image = batch_sampler[0]
    print(sampler_first_image)
    print(sampler_first_image.shape)
    print(sampler_first_image.sum(dim=-1))

    pi_norm, _, pi_raw = distrib.get_pi(1e-8)
    print("Raw params", pi_raw)
    pi_raw_recov = distrib.invert_pi(pi_norm)
    print("Rocovered raw params", pi_raw_recov)

    print("------------------------------ctp----------------------------")
    ctp_pi = PiWithCTP(
        num_patches,
        num_ctp=num_distributions,
        dim_ctp=dim_ctp,
        marginal_initialization="uniform",
        hiddens=[],
    )
    # print(ctp_pi)
    print(ctp_pi())
    print("Num params ctp = ", get_num_parameters(ctp_pi))

    dim_ctp = 19
    ctp_hiddens = [78, 78, 78]
    ctp_hiddens = []
