from models.gumbel_distrib import (
    GumbelDistribution,
    GumbelDistributionLogits,
    GumbelDistributionSoftmaxAct,
    GumbelDistributionBijectiveSoftmax,
)

import torch
import pytorch_lightning as pl


class PatchSelector(pl.LightningModule):
    def __init__(
        self,
        # data args
        num_patches,
        mask_ratio=0.75,
        dim_ctp=0,
        pi_dropout=0,
        ctp_dropout=0,
        pi_layer_norm=False,
        gumbel_learn_mode="pi",
    ):
        super().__init__()

        self.num_patches_tot = num_patches
        self.num_obs_patches = int((1 - mask_ratio) * self.num_patches_tot)

        gumbel_args = dict(
            num_categories=self.num_patches_tot,
            num_distributions=self.num_obs_patches,
            marginal_initialization="random",
            dim_ctp=dim_ctp,
            pi_dropout=pi_dropout,
            ctp_dropout=ctp_dropout,
            layer_norm=pi_layer_norm,
        )

        if gumbel_learn_mode == "pi":
            self.gumbel_distrib = GumbelDistribution(**gumbel_args)
        elif gumbel_learn_mode == "logits":
            self.gumbel_distrib = GumbelDistributionLogits(**gumbel_args)
        elif gumbel_learn_mode == "softmax":
            self.gumbel_distrib = GumbelDistributionSoftmaxAct(**gumbel_args)
        elif gumbel_learn_mode == "bij_softmax":
            self.gumbel_distrib = GumbelDistributionBijectiveSoftmax(**gumbel_args)
        else:
            raise NotImplementedError(
                f"Incorrect gumbel_mode'{gumbel_learn_mode}', choose between 'pi', 'softmax', 'logits' or 'bij_softmax'"
            )

    def forward(
        self,
        x,
        random,
        temperature=1.0,
        hard=False,
        **gumbel_kwargs,
    ):
        """
        x: (N, L, D)
        """

        num_batches = x.shape[0]  # b
        embedding_dim = x.shape[2]  # d
        # Get batch of gumbel samples
        batch_sampler, distrib_dict = self.gumbel_distrib.batch_sample_joint(
            num_batches, temperature, random, hard=hard, ret_GJS=True, **gumbel_kwargs
        )

        x_subset = torch.bmm(batch_sampler, x)

        return x_subset, distrib_dict


class VideoPatchSelector(PatchSelector):
    def __init__(
        self,
        num_patches,
        mask_ratio=0.75,
        dim_ctp=0,
        pi_dropout=0,
        ctp_dropout=0,
        pi_layer_norm=False,
        gumbel_learn_mode="pi",
    ):
        super().__init__(
            num_patches,
            mask_ratio,
            dim_ctp,
            pi_dropout,
            ctp_dropout,
            pi_layer_norm,
            gumbel_learn_mode,
        )

    def forward(
        self,
        x,
        random,
        temperature=1.0,
        hard=False,
        **gumbel_kwargs,
    ):
        """
        x: (N, S, L, D)
        """

        N = x.shape[0]
        S = x.shape[1]
        L = x.shape[2]
        D = x.shape[3]

        # Get batch of gumbel samples
        batch_sampler, distrib_dict = self.gumbel_distrib.batch_sample_joint(
            N, temperature, random, hard=hard, ret_GJS=True, **gumbel_kwargs
        )

        # same sample for each full sequence
        batch_sampler = batch_sampler.unsqueeze(1).repeat((1, S, 1, 1))

        # reshape for batch matmul
        batch_sampler = batch_sampler.view((N * S), self.num_obs_patches, L)
        x = x.view((N*S, L, D))

        x_subset = torch.bmm(batch_sampler, x)
        x_subset = x_subset.view((N, S, self.num_obs_patches, D))

        return x_subset, distrib_dict