import torch
import torch.nn as nn
import numpy as np

from functools import partial
from timm.models.vision_transformer import Block

from models.vit_base_class import ViTBaseClass


def positional_encoding_1d(seq_len, d, n=10000):
    P = np.zeros((seq_len, d))
    for k in range(seq_len):
        for i in np.arange(int(d / 2)):
            denominator = np.power(n, 2 * i / d)
            P[k, 2 * i] = np.sin(k / denominator)
            P[k, 2 * i + 1] = np.cos(k / denominator)
    return P


class TimeSeriesTransformer(ViTBaseClass):
    def __init__(
        self,
        max_sequence_len=16,
        embed_dim=256,
        depth=8,
        num_heads=8,
        mlp_ratio=4,
        global_pool=False,
        norm_layer=partial(nn.LayerNorm, eps=1e-6),
    ) -> None:
        super().__init__()
        self.max_sequence_len = max_sequence_len
        self.global_pool = global_pool

        # CLS token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim), requires_grad=True)
        # fixed 2D sin-cos positional embedding
        self.pos_embed = nn.Parameter(
            torch.zeros(1, max_sequence_len + 1, embed_dim), requires_grad=False
        )

        # transformer blocks
        self.blocks = nn.ModuleList(
            [
                Block(
                    embed_dim,
                    num_heads,
                    mlp_ratio,
                    qkv_bias=True,
                    norm_layer=norm_layer,
                )
                for i in range(depth)
            ]
        )

        self.initialize_weights()

    def initialize_weights(self):
        pos_embed = positional_encoding_1d(
            self.max_sequence_len + 1, self.pos_embed.shape[-1]
        )
        self.pos_embed.data.copy_(torch.from_numpy(pos_embed).float().unsqueeze(0))

        torch.nn.init.normal_(self.cls_token, std=0.02)

        # initialize nn.Linear and nn.LayerNorm
        self.apply(self._init_weights)

    def forward(self, x):
        """
        x: the sequence of features (N, S, D)
        """
        S = x.shape[1]
        assert (
            S <= self.max_sequence_len
        ), f"sequence longer ({S}) than maximum time pos enc ({self.max_sequence_len})"

        # add pos embed
        x += self.pos_embed[:, 1:S+1, :]

        # append class token
        cls_token = self.cls_token + self.pos_embed[:, :1, :]
        cls_tokens = cls_token.expand(x.shape[0], -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)

        for blk in self.blocks:
            x = blk(x)

        if self.global_pool:
            z = x[:, 1:, :].mean(dim=1)  # global pool without cls token
        else:
            z = x[:, 0]

        return z


if __name__ == "__main__":
    test_seq = torch.randn((10, 16, 40))
    model = TimeSeriesTransformer(
        max_sequence_len=16, embed_dim=40, depth=1, num_heads=2, global_pool=False
    )
    print(model(test_seq).shape)
