from copy import deepcopy
import matplotlib.pyplot as plt
import matplotlib
import os
from functools import partial
import torch
from torch.nn.parallel import DistributedDataParallel
import torch.nn as nn
import timm.optim.optim_factory as optim_factory
from torch._six import inf
import sys
import custom_datasets
import pandas as pd
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import yaml
import numpy as np
import math
from custom_datasets import EchoNet

matplotlib.use("Agg")


def _sample_binarize(x):
    return torch.distributions.Bernoulli(probs=x).sample()


def _binarize(x, threshold=0.5):
    x[x >= threshold] = 1
    x[x < threshold] = 0
    return x


TRANSFORMS_DICT = {
    "imagenet": {
        "train": lambda img_size: transforms.Compose(
            [
                transforms.RandomResizedCrop(
                    img_size,
                    scale=(0.2, 1.0),
                    interpolation=transforms.InterpolationMode.BICUBIC,
                ),  # 3 is bicubic
                transforms.RandomHorizontalFlip(),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        ),
        "test": lambda img_size: transforms.Compose(
            [
                transforms.Resize((img_size, img_size)),
                transforms.ToTensor(),
                transforms.Normalize(
                    mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]
                ),
            ]
        ),
    },
    "echonet": {
        "train": lambda img_size: transforms.Compose(
            [
                transforms.Resize((img_size, img_size)),
                transforms.Normalize(
                    mean=[0.1294], std=[0.1965]
                ),
            ]
        ),
        "test": lambda img_size: transforms.Compose(
            [
                transforms.Resize((img_size, img_size)),
                transforms.Normalize(
                    mean=[0.1294], std=[0.1965]
                ),
            ]
        ),
    },
}


def plot_distribution(
    pi_raw: torch.tensor,
    base_path: str,
    base_name: str,
    num_observed_patches: int,
    n_patch_per_side=14,
):
    save_name = "pi_marginal" + base_name + ".png"
    save_path = os.path.join(base_path, save_name)
    print(
        "Plotting distribution--",
        save_path,
    )
    plt.matshow(pi_raw.numpy().reshape(n_patch_per_side, n_patch_per_side))
    plt.savefig(save_path)
    plt.close()


def save_pi_snapshot(
    pi_raw: torch.tensor,
    method,
    output_dir: str,
    num_observed_patches: int,
    n_patch_per_side: int,
    save_individual_distribs=False,
    base_name="",
):
    if method == "multi":
        multi_subfolder = os.path.join(output_dir, "individual")
        os.makedirs(multi_subfolder, exist_ok=True)
        pi_raw_combined = torch.zeros(pi_raw[0].shape)
        pi_summed = torch.zeros(pi_raw[0].shape)
        for idx, row in enumerate(pi_raw):
            if save_individual_distribs:
                plot_distribution(
                    row,
                    multi_subfolder,
                    str(idx) + "_" + base_name,
                    num_observed_patches,
                    n_patch_per_side=n_patch_per_side,
                )
            # print("ROW ", row)
            max_, argmax_ = torch.max(row.unsqueeze(0), dim=1)
            row_masked = torch.zeros(row.shape)
            row_masked[argmax_] = max_
            pi_raw_combined += row_masked
            pi_summed += row
        plot_distribution(
            pi_raw_combined,
            output_dir,
            "_COMBINED_" + base_name,
            num_observed_patches,
            n_patch_per_side=n_patch_per_side,
        )
        plot_distribution(
            pi_summed,
            output_dir,
            "_SUMMED_" + base_name,
            num_observed_patches,
            n_patch_per_side=n_patch_per_side,
        )
        _, selected_inds = torch.max(pi_raw, dim=1)

    elif method == "single":
        plot_distribution(
            pi_raw.squeeze(0),
            output_dir,
            base_name,
            num_observed_patches,
            n_patch_per_side=n_patch_per_side,
        )

        _, selected_inds = torch.topk(pi_raw, num_observed_patches)
    else:
        raise Exception("Invalid sampling method")


def get_dataset_mean_std(dataset, num_workers=0):
    from torch.utils.data import DataLoader

    dataloader = DataLoader(dataset, batch_size=1, num_workers=num_workers)
    from tqdm import tqdm

    probe_im, _ = next(iter(dataloader))
    channels = probe_im.shape[1]
    mins = torch.tensor([torch.inf] * channels)
    maxes = torch.tensor([-torch.inf] * channels)
    sum_ = 0
    sq_sum = 0
    count = 0
    for im, _ in tqdm(dataloader):
        # im = im.squeeze(0) numbers
        dims = im.shape
        sum_ += torch.sum(im, dim=(0, 2, 3))
        sq_sum += torch.sum(torch.pow(im, 2), dim=(0, 2, 3))
        count += im[:, 0, :].flatten().shape[0]
        mins = torch.minimum(mins, torch.amin(im, dim=(0, 2, 3)))
        maxes = torch.maximum(maxes, torch.amax(im, dim=(0, 2, 3)))
    print(dims)
    mean = sum_ / count
    sq_mean = sq_sum / count
    std = torch.sqrt(sq_mean - torch.pow(mean, 2))
    return mean, std, (maxes, mins)


def get_num_parameters(model):
    sum = 0
    for param in list(model.parameters()):
        sum += param.numel()
    return sum

def add_ADASYN_rows(df_in, target_col, frac_max=0.1, classification=False):
    assert(frac_max > 0 and frac_max <= 1)
    df = df_in.copy()
    if classification:
        df['bin'] = df[target_col]
        counts = df['bin'].value_counts()
        max_count = counts.max()
    else:
        bins = 30
        df['bin'], _ = pd.cut(
            df[target_col], bins, labels=False, retbins=True)
        df['bin'] = df['bin'].astype(np.int16)
        n = len(df)
        counts = df['bin'].value_counts()
        counts[counts < 1] = 1
        max_count = counts.max()

    df['Augment'] = 0
    dfs = [df]
    for i, group in df.groupby('bin'):
        n_sample = int((max_count-len(group))*frac_max)
        n_sample = max(n_sample-1, 0)
        group = group.sample(n_sample, replace=True)
        group['Augment'] = 1
        dfs.append(group)
    df_extd = pd.concat(dfs).reset_index(drop=True)

    # import matplotlib.pyplot as plt
    # plt.figure()
    # plt.hist(df_in[target_col].values, bins=10)
    # plt.hist(df_in[target_col].values, bins=50)
    # plt.hist(df_in[target_col].values, bins=bins)
    # plt.title('Original')

    # plt.figure()
    # plt.title(f'Max addition/bin = {frac_max*100}% of max bin size')
    # plt.hist(df_extd[target_col].values, bins=10)
    # plt.hist(df_extd[target_col].values, bins=50)
    # plt.hist(df_extd[target_col].values, bins=bins)
    # plt.show(block=True)

    df_extd = df_extd.drop(columns=['bin'])
    print(f'{len(df_extd) - len(df)} ADASYN samples added.')

    return df_extd

def get_baselines(train_df, val_df, target_col):
    train_tar_mean = train_df[target_col].mean()
    val_guess_mse = np.mean(
        np.power(val_df[target_col].values - train_tar_mean, 2))
    val_guess_rmse = np.sqrt(val_guess_mse + np.finfo(float).eps)
    print(
        'Mean guess validation MSE/RMSE: '
        f'{val_guess_mse:.5f} / {val_guess_rmse:.5f}'
        ' (Unit Scale)')
    train_tar_mean = (train_df[target_col]*100).mean()
    val_guess_mse = np.mean(
        np.power((val_df[target_col]*100).values - train_tar_mean, 2))
    val_guess_rmse = np.sqrt(val_guess_mse + np.finfo(float).eps)
    print(
        'Mean guess validation MSE/RMSE: '
        f'{val_guess_mse:.5f} / {val_guess_rmse:.5f}'
        ' (Percentage Units)')

    n_rand = 5
    rand_mse = []
    rand_rmse = []
    for _ in range(n_rand):
        rand_guess = np.random.random(np.shape(val_df[target_col].values))
        val_rand_guess_mse = np.mean(
            np.power(val_df[target_col].values - rand_guess, 2))
        val_rand_guess_rmse = np.sqrt(val_rand_guess_mse + np.finfo(float).eps)
        rand_mse.append(val_rand_guess_mse)
        rand_rmse.append(val_rand_guess_rmse)
    rand_mse = np.mean(np.array(rand_mse))
    rand_rmse = np.mean(np.array(rand_rmse))
    print(
        f'Random ({n_rand} run) guess validation MSE/RMSE: '
        f'{rand_mse:.5f} / {rand_rmse:.5f}'
        ' (Unit Scale)')
    
def trim_outlier_examples(df, args, trim_fps=True, trim_length=True, trim_res=True):
    len_orig = len(df)
    if trim_fps:
        # cut off videos with abnormal lengths and FPS and resolution
        normal_fps_inds = (df['FPS'] >= 40) & (df['FPS'] <= 70)
        df = df[normal_fps_inds]
    if trim_length:
        normal_length_inds = df['NumberOfFrames'] >= args.sequence_len * \
            args.sampling_rate
        df = df[normal_length_inds]
    if trim_res:
        resolution_inds = (df['FrameHeight'] == 112) & (
            df['FrameWidth'] == 112)
        df = df[resolution_inds]
    df = df.reset_index(drop=True)
    num_trimmed = len_orig - len(df)
    if num_trimmed:
        print(f"{num_trimmed} examples trimmed!")
    return df

def get_EchoNet_train_test_split(args,
                                 dtype=torch.float32,
                                 return_dfs=False, test_only=False):
    kwargs = dict(
        sequence_len=args.sequence_len,
        sampling_rate=args.sampling_rate,
        num_classes=args.num_classes,
        target_encoding=args.target_encoding,
        dtype=dtype
    )

    transform=TRANSFORMS_DICT["echonet"]["train"](args.input_height)
    test_transform=TRANSFORMS_DICT["echonet"]["test"](args.input_height)
    target_transform=None
    adasyn_transform=None # TODO: revisit ADASYN

    csv = 'FileList.csv'
    df = pd.read_csv(os.path.join(args.data_path, csv))
    df['FileName'] = args.data_path + os.sep + \
        'Videos' + os.sep + df['FileName'] + '.avi'

    target_scale = args.target_scale
    df['EF'] = (df['EF'] / 100) * target_scale

    if kwargs['target_encoding']:
        df['EF'], bins = pd.cut(
            df['EF'], kwargs['num_classes'], labels=False, retbins=True)
        df['EF'] = df['EF'].astype(np.int8)
        print('Categories split into the following bins: ', bins)



    train_df = df[df['Split'] == 'TRAIN'].reset_index(drop=True)
    val_df = df[df['Split'] == 'VAL'].reset_index(drop=True)
    test_df = df[df['Split'] == 'TEST'].reset_index(drop=True)

    # train_df = trim_outlier_examples(train_df, args)
    # val_df = trim_outlier_examples(val_df, args)


    if args.subset:
        subset = args.subset
        assert(subset > 0 and subset <= 1)
        if args.random_subset:
            train_df = train_df.sample(frac=subset, random_state=args.seed)
            train_df = train_df.reset_index(drop=True)
        else:
            train_df = train_df.loc[:subset*len(df), :]

    if args.adasyn > 0:
        train_df = add_ADASYN_rows(train_df, 'EF', args.adasyn)

    train_dataset = EchoNet(train_df, **kwargs,
                            transform=transform,
                            adasyn_transform=adasyn_transform,
                            target_transform=target_transform,)
    val_dataset = EchoNet(val_df, **kwargs, transform=test_transform)
    test_dataset = EchoNet(test_df, **kwargs, transform=test_transform)

    print('Train/val/test sequences: {}/{}/{}'.format(len(train_dataset),
          len(val_dataset), len(test_dataset)))

    get_baselines(train_df, val_df, 'EF')

    if return_dfs:
        target_col = 'EF'
        dfs = (train_df, val_df, test_df)
        return (train_dataset, val_dataset, test_dataset), dfs, target_col
    else:
        return train_dataset, val_dataset, test_dataset

def get_loss_func(args, reduction="none"):
    if args.loss_type == "mse":
        loss_func = nn.MSELoss(reduction=reduction)
    elif args.loss_type == "bce":
        loss_func = torch.nn.BCEWithLogitsLoss(reduction=reduction)
    else:
        raise NotImplementedError(f"Invalid loss func {args.loss_type} specified")
    return loss_func


def get_rank() -> int:
    rank_keys = ("RANK", "SLURM_PROCID", "LOCAL_RANK")
    for key in rank_keys:
        rank = os.environ.get(key)
        if rank is not None:
            return int(rank)
    return 0
