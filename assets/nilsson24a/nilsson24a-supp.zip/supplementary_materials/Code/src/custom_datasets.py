import torchvision.transforms as transforms
import os
import pandas as pd
from PIL import Image
import torch
import yaml
import numpy as np
from torch.utils.data import Dataset
from torchvision import datasets
import json
import random
import cv2

RGB_DICT = {1: 'GRAY',
            3: 'RGB'}

PIL_RGB_DICT = {1: 'L',
                3: 'RGB'}

def to_onehot(cls_ind, num_classes, dtype=torch.float32):
    cls_ind = cls_ind.long()
    y_vec = torch.zeros(num_classes, dtype=dtype)
    y_vec[cls_ind] = 1
    return y_vec


def to_ordinal(cls_ind, num_classes, dtype=torch.float32):
    cls_ind = cls_ind.long()
    y_vec = torch.zeros(num_classes, dtype=dtype)
    y_vec[:cls_ind+1] = 1
    return y_vec


ONEHOT_ENCODINGS = {'onehot': to_onehot,
                    'ordinal': to_ordinal}

class EchoNet(Dataset):
    def __init__(self, df,
                 sequence_len, sampling_rate,
                 transform=None, target_transform=None,
                 num_classes=None, target_encoding=None,
                 adasyn_transform=None,
                 dtype=torch.float32):
        self.df = df
        self.sequence_len = sequence_len
        self.sampling_rate = sampling_rate
        self.dtype = dtype
        self.num_classes = num_classes
        self.transform = transform
        self.target_transform = target_transform
        self.target_encoding = target_encoding
        self.adasyn_transform = adasyn_transform

        assert(target_encoding in list(ONEHOT_ENCODINGS.keys()) + [0])

        self.frames_to_sample = np.arange(
            0, self.sampling_rate * self.sequence_len,
            self.sampling_rate,
            dtype=np.int16)

    def __len__(self):
        return len(self.df)

    def __getitem__(self, seq):
        path = self.df.loc[seq, ['FileName']].values[0]

        vid = cv2.VideoCapture(path)
        # n_frames = int(vid.get(cv2.CAP_PROP_FRAME_COUNT))
        # fps = vid.get(cv2.CAP_PROP_FPS)
        # time = n_frames/fps
        # im_seq = np.zeros(
        #     (self.sequence_len, 1,
        #      112, 112))
        frames = []

        for i in range(self.sequence_len):
            ret, frame = vid.read()
            if ret:
                frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                frame = np.reshape(frame, (*frame.shape, 1))
                frame = frame.transpose((2, 0, 1))
                # print(np.max(frame))
                frame = frame / 255
                # im_seq[i, :] = frame
                frames.append(torch.tensor(frame, dtype=self.dtype).unsqueeze(0))
            else:
                if i > 0: #video ended
                    break
                else:
                    raise ValueError('Failed to load frames from {}'.format(path))
            
            # skip self.sampling_rate-1 frames
            for u in range(self.sampling_rate-1):
                ret, frame = vid.read()
        vid.release()

        im_seq = torch.cat(frames)
        label = torch.tensor([self.df.loc[seq, 'EF']], dtype=self.dtype).unsqueeze(0)

        if self.target_encoding:
            label = ONEHOT_ENCODINGS[self.target_encoding](label, self.num_classes)

        if self.adasyn_transform is not None:
            if self.df.loc[seq, ['Augment']].item():
                im_seq = self.adasyn_transform(im_seq)
            elif self.transform:
                im_seq = self.transform(im_seq)
        elif self.transform:
            im_seq = self.transform(im_seq)
        if self.target_transform:
            label = self.target_transform(label)

        return im_seq, label

if __name__ == "__main__":
    from utils import get_dataset_mean_std

    data_folder = "echonet"
    transform_train = transforms.ToTensor()
    df = ...
    dataset = EchoNet(df)
    print(get_dataset_mean_std(dataset))
