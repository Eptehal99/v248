# Stochastic Regularization of ViTs for Echocardiography

### Download data
Sign up and download (non-commercial research purposes only):

https://echonet.github.io/dynamic/index.html#access

Unzip with 7z (unzip does not work with this zip archive on Linux)

`7z e EchoNet-Dynamic.zip `

#### Install requirements (Conda)
`conda env create -f environment.yml`

`conda activate StoReg`


#### OR build apptainer container for the Conda env
`apptainer build --nv sto_reg.sif apptainer_defs/conda_appt_env.def`

Later, run with
`apptainer exec --nv sto_reg.sif *python launch command*`

### OpenCV problems
You may need to manually set this variable for opencv to work:

`export LD_LIBRARY_PATH=/path/to/your/libgl:$LD_LIBRARY_PATH`

find the path that contains `libGL.so.1` (use the path to the folder, not the file itself) with

` find ~/ -name libGL.so.1`

test import with 

```
conda activate StoReg
python -c "import cv2"
```

### Framework/structure
We utilize Pytorch Lightning. We define the models in `src/models/`, and wrap them with Lightning modules which contain the training code. The training wrappers are found in `src/pl_wrappers.py`.

A number of callbacks such as for annealing the LR and temperature are found in `src/pl_callbacks.py`. They can be toggeled by providing the corresponding argument, i.e. `--anneal_temp=True`.

### Train 
Train and reproduce G-ViT with optimal hyperparameters:

`python src/main.py --config=configs/config_gumbel_timm.yaml --data_path=<your-echonet-folder>`

Train and reproduce V-ViT with optimal hyperparameters:

`python src/main.py --config=configs/config_baseline_timm.yaml --data_path=<your-echonet-folder>`

### Logging
We utilize WandB for detailed logging, so make sure to sign in with

`wandb login`

and specify the WandB arguments

`python src/main.py --config=<your-config> --wandb=<your-project> --wandb_entity=<your-entity>`

The full list of arguments and their descriptions can be found in `src/parse_args.py`

### Argument/config priority
Provided command line args > config values > argparse defaults

